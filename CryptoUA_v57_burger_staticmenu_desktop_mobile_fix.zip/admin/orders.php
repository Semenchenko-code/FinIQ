<?php
require_once __DIR__ . '/../helpers.php';
$u = require_login();
include __DIR__ . '/_layout.php';

$pdo = db();

if($_SERVER['REQUEST_METHOD']==='POST'){
  $id = (int)($_POST['id'] ?? 0);
  $action = $_POST['action'] ?? '';
  if($id>0){
    if($action==='status'){
      $st = strtoupper(trim((string)($_POST['status'] ?? 'IN_WORK')));
      $allowed = ['NEW','IN_WORK','WAIT_PAYMENT','PAID','COMPLETED','REJECTED','CANCELLED'];
      if(!in_array($st,$allowed,true)) $st='IN_WORK';
      $old = $pdo->query("SELECT status FROM orders WHERE id=".(int)$id)->fetchColumn();
      $pdo->prepare("UPDATE orders SET status=?, updated_at=? WHERE id=?")->execute([$st, now_iso(), $id]);
      audit('ORDER_STATUS', ['orderId'=>$id,'from'=>$old,'to'=>$st,'by'=>$u['username']]);
    }
    if($action==='notes'){
      $notes = trim((string)($_POST['notes'] ?? ''));
      $pdo->prepare("UPDATE orders SET notes=?, updated_at=? WHERE id=?")->execute([$notes, now_iso(), $id]);
      audit('ORDER_NOTES', ['orderId'=>$id]);
    }
  }
}

$view = isset($_GET['view']) ? (int)$_GET['view'] : 0;

if($view>0){
  $o = $pdo->prepare("SELECT * FROM orders WHERE id=?");
  $o->execute([$view]);
  $order = $o->fetch();
  if(!$order){ echo "<div class='card'>Not found</div>"; include __DIR__.'/_footer.php'; exit; }
  ?>
  <div class="card">
    <h2 style="margin:0 0 6px">Order #<?= (int)$order['id'] ?></h2>
    <div class="muted">Created: <?= h($order['created_at']) ?> · Status: <span class="tag"><?= h($order['status']) ?></span></div>
  </div>

  <div class="card">
    <table>
      <tr><th>Mode</th><td><?= h($order['mode']) ?></td></tr>
      <tr><th>From</th><td><?= h($order['from_amount'].' '.$order['from_asset']) ?></td></tr>
      <tr><th>To</th><td><?= h($order['to_amount'].' '.$order['to_asset']) ?></td></tr>
      <tr><th>Payout</th><td><?= h($order['payout']) ?></td></tr>
      <tr><th>Name</th><td><?= h($order['name']) ?></td></tr>
      <tr><th>Contact</th><td><?= h($order['contact']) ?></td></tr>
      <tr><th>Fee</th><td><?= h($order['fee_pct']) ?>%</td></tr>
    </table>
  </div>

  <div class="card">
    <h3 style="margin:0 0 10px">Update status</h3>
    <form method="post">
      <input type="hidden" name="id" value="<?= (int)$order['id'] ?>">
      <input type="hidden" name="action" value="status">
      <select name="status">
        <?php foreach(['NEW','IN_WORK','WAIT_PAYMENT','PAID','COMPLETED','REJECTED','CANCELLED'] as $st): ?>
          <option value="<?= $st ?>" <?= $order['status']===$st?'selected':'' ?>><?= $st ?></option>
        <?php endforeach; ?>
      </select>
      <div style="height:10px"></div>
      <button class="btn" type="submit">Save</button>
      <a class="btn2" href="/admin/orders.php">Back</a>
    </form>
  </div>

  <div class="card">
    <h3 style="margin:0 0 10px">Notes</h3>
    <form method="post">
      <input type="hidden" name="id" value="<?= (int)$order['id'] ?>">
      <input type="hidden" name="action" value="notes">
      <textarea name="notes"><?= h($order['notes']) ?></textarea>
      <div style="height:10px"></div>
      <button class="btn" type="submit">Save notes</button>
    </form>
  </div>
  <?php
  include __DIR__ . '/_footer.php';
  exit;
}

$status = $_GET['status'] ?? '';
$params = [];
$where = '1=1';
if ($status) { $where .= ' AND status=?'; $params[] = $status; }

$st = $pdo->prepare("SELECT id,created_at,status,mode,from_amount,from_asset,to_amount,to_asset,name,contact FROM orders WHERE $where ORDER BY id DESC LIMIT 200");
$st->execute($params);
$rows = $st->fetchAll();

?><div class="card">
  <h2 style="margin:0 0 6px">Orders</h2>
  <div class="muted">Останні 200 заявок</div>
</div>

<div class="card">
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <?php foreach(['','NEW','IN_WORK','WAIT_PAYMENT','PAID','COMPLETED','REJECTED'] as $s): ?>
      <a class="pill" href="/admin/orders.php<?= $s?('?status='.$s):'' ?>"><?= $s?:'ALL' ?></a>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <table>
    <tr><th>ID</th><th>Created</th><th>Status</th><th>Direction</th><th>Amounts</th><th>User</th></tr>
    <?php foreach($rows as $o): ?>
      <tr>
        <td><a href="/admin/orders.php?view=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
        <td class="muted"><?= h($o['created_at']) ?></td>
        <td><span class="tag"><?= h($o['status']) ?></span></td>
        <td class="muted"><?= h($o['mode']) ?></td>
        <td><?= h($o['from_amount'].' '.$o['from_asset'].' → '.$o['to_amount'].' '.$o['to_asset']) ?></td>
        <td class="muted"><?= h(trim(($o['name']??'').' '.($o['contact']??''))) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
