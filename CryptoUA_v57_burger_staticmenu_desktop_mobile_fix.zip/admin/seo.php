<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';
$key = 'seo_' . $lang;

$seo = setting_get($key, [
  'title' => 'CryptoUA — P2P Crypto ⇄ UAH',
  'description' => 'Обмін криптовалют на гривні та у зворотному напрямку. Фіксація курсу, оператори 24/7.',
  'keywords' => 'crypto,uah,обмін,USDT,BTC,ETH,p2p',
  'og_image' => '/assets/og-cover.png'
]);

$robotsPath = __DIR__ . '/../robots.txt';
$robots = file_exists($robotsPath) ? file_get_contents($robotsPath) : "User-agent: *\nAllow: /\n";

$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $seo['title'] = trim($_POST['title'] ?? '');
  $seo['description'] = trim($_POST['description'] ?? '');
  $seo['keywords'] = trim($_POST['keywords'] ?? '');
  $seo['og_image'] = trim($_POST['og_image'] ?? '/assets/og-cover.png');
  setting_set($key, $seo);

  $robots = (string)($_POST['robots'] ?? $robots);
  file_put_contents($robotsPath, $robots);

  // sitemap.xml from pages
  $pdo=db();
  $base = rtrim(cfg('BASE_URL',''),'/');
  $urls=[];
  $urls[] = ['loc'=>$base.'/?lang=uk','lastmod'=>date('Y-m-d')];
  $urls[] = ['loc'=>$base.'/?lang=en','lastmod'=>date('Y-m-d')];
  $pages = $pdo->query("SELECT lang,slug,updated_at FROM pages")->fetchAll();
  foreach($pages as $p){
    $urls[] = ['loc'=>$base.'/p.php?slug='.$p['slug'].'&lang='.$p['lang'], 'lastmod'=>substr($p['updated_at'],0,10)];
  }
  $xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
  $xml .= "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n";
  foreach($urls as $u){
    $xml .= "  <url><loc>".htmlspecialchars($u['loc'],ENT_QUOTES)."</loc><lastmod>{$u['lastmod']}</lastmod></url>\n";
  }
  $xml .= "</urlset>\n";
  file_put_contents(__DIR__ . '/../sitemap.xml', $xml);

  audit('SEO_UPDATE', ['lang'=>$lang]);
  $ok='Saved ✅';
}

?><div class="card">
  <h2 style="margin:0 0 6px">SEO (<?= h(strtoupper($lang)) ?>)</h2>
  <div class="muted">Title/Description/Keywords + OG. Robots і sitemap генеруються.</div>
  <?php if($ok): ?><div class="muted" style="margin-top:8px"><?= h($ok) ?></div><?php endif; ?>
</div>

<div class="card">
  <div style="display:flex;gap:10px">
    <a class="pill" href="/admin/seo.php?lang=uk">UA</a>
    <a class="pill" href="/admin/seo.php?lang=en">EN</a>
    <a class="pill" href="/admin/media.php?lang=<?= h($lang) ?>">Media</a>
  </div>
</div>

<div class="card">
<form method="post">
  <label class="muted">Title</label>
  <input name="title" value="<?= h($seo['title'] ?? '') ?>">
  <div style="height:10px"></div>

  <label class="muted">Description</label>
  <input name="description" value="<?= h($seo['description'] ?? '') ?>">
  <div style="height:10px"></div>

  <label class="muted">Keywords</label>
  <input name="keywords" value="<?= h($seo['keywords'] ?? '') ?>">
  <div style="height:10px"></div>

  <label class="muted">OG Image path (upload in Media)</label>
  <input name="og_image" value="<?= h($seo['og_image'] ?? '/assets/og-cover.png') ?>">
  <div style="height:10px"></div>

  <label class="muted">robots.txt</label>
  <textarea name="robots"><?= h($robots) ?></textarea>

  <div style="height:14px"></div>
  <button class="btn" type="submit">Save</button>
</form>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
