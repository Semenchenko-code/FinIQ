<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$pdo = db();
$isMysql = is_mysql();

$ok = '';
$err = '';

function clean_asset($s): string {
  $s = strtoupper(trim((string)$s));
  $s = preg_replace('/[^A-Z0-9_\-]/', '', $s);
  return $s;
}

function upsert_direction($pdo, bool $isMysql, string $from, string $to, int $enabled, int $sort){
  $from = strtoupper($from);
  $to   = strtoupper($to);
  if ($isMysql) {
    $sql = "INSERT INTO directions(from_asset,to_asset,enabled,sort_order,updated_at)
            VALUES(?,?,?,?,?)
            ON DUPLICATE KEY UPDATE enabled=VALUES(enabled), sort_order=VALUES(sort_order), updated_at=VALUES(updated_at)";
  } else {
    $sql = "INSERT INTO directions(from_asset,to_asset,enabled,sort_order,updated_at)
            VALUES(?,?,?,?,?)
            ON CONFLICT(from_asset,to_asset) DO UPDATE SET
              enabled=excluded.enabled, sort_order=excluded.sort_order, updated_at=excluded.updated_at";
  }
  $st = $pdo->prepare($sql);
  $st->execute([$from,$to,$enabled,$sort,now_iso()]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';

  try {
    if ($action === 'add_pair') {
      $from = clean_asset($_POST['from_asset'] ?? '');
      $to   = clean_asset($_POST['to_asset'] ?? '');
      $sort = (int)($_POST['sort_order'] ?? 100);
      $enabled = isset($_POST['enabled']) ? 1 : 0;
      $twoWay  = isset($_POST['two_way']) ? 1 : 0;

      if ($from === '' || $to === '' || $from === $to) throw new Exception('Bad pair');
      if (strlen($from) > 16 || strlen($to) > 16) throw new Exception('Asset code too long');

      upsert_direction($pdo, $isMysql, $from, $to, $enabled, $sort);

      if($twoWay && !($from==='UAH' && $to==='UAH') && $from !== $to){
        upsert_direction($pdo, $isMysql, $to, $from, $enabled, $sort+1);
      }

      audit('DIRECTION_PAIR_ADD', ['from'=>$from,'to'=>$to,'two_way'=>$twoWay]);
      setting_set('calc_preview_ver', time());
      $ok = "Додано напрям(и) ✅";
    }

    if ($action === 'update') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) throw new Exception('Bad id');

      $enabled = isset($_POST['enabled']) ? 1 : 0;
      $sort = (int)($_POST['sort_order'] ?? 100);

      $pdo->prepare("UPDATE directions SET enabled=?, sort_order=?, updated_at=? WHERE id=?")
          ->execute([$enabled,$sort,now_iso(),$id]);

      audit('DIRECTION_PAIR_UPDATE', ['id'=>$id,'enabled'=>$enabled,'sort'=>$sort]);
      setting_set('calc_preview_ver', time());
      $ok = "Збережено ✅";
    }

    if ($action === 'delete') {
      $id = (int)($_POST['id'] ?? 0);
      if ($id <= 0) throw new Exception('Bad id');

      $pdo->prepare("DELETE FROM directions WHERE id=?")->execute([$id]);

      audit('DIRECTION_PAIR_DELETE', ['id'=>$id]);
      setting_set('calc_preview_ver', time());
      $ok = "Видалено ✅";
    }
  } catch(Throwable $e) {
    $err = $e->getMessage();
  }
}

$dirs = directions_list(false);
?>
<div class="card">
  <h2 style="margin:0 0 6px">Directions</h2>
  <div class="muted">Напрями, які відображаються в калькуляторі (пара from → to). Для налаштування курсу/комісії/лімітів — <a href="/admin/rates.php">Rates & Fees</a>.</div>
  <?php if($ok): ?><div style="margin-top:10px" class="muted"><?= h($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div style="margin-top:10px;color:#ffb4b4"><?= h($err) ?></div><?php endif; ?>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Додати напрям</h3>
  <form method="post">
    <input type="hidden" name="action" value="add_pair">
    <div class="row">
      <div>
        <label class="muted">From</label>
        <input name="from_asset" placeholder="UAH / USDT / BTC" required>
      </div>
      <div>
        <label class="muted">To</label>
        <input name="to_asset" placeholder="USDT / UAH / BTC" required>
      </div>
    </div>
    <div class="row">
      <div>
        <label class="muted">Sort</label>
        <input name="sort_order" type="number" step="1" value="100">
      </div>
      <div style="display:flex;align-items:end;gap:16px">
        <label style="display:flex;gap:8px;align-items:center">
          <input type="checkbox" name="enabled" checked>
          <span class="muted">Enabled (показувати)</span>
        </label>
        <label style="display:flex;gap:8px;align-items:center">
          <input type="checkbox" name="two_way" checked>
          <span class="muted">Create reverse</span>
        </label>
      </div>
    </div>
    <div style="margin-top:10px">
      <button class="btn" type="submit">Add</button>
    </div>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Список напрямів</h3>

  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Pair</th>
        <th>Enabled</th>
        <th>Sort</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
    <?php foreach($dirs as $d): ?>
      <tr>
        <td><?= (int)$d['id'] ?></td>
        <td><b><?= h($d['from_asset']) ?></b> → <b><?= h($d['to_asset']) ?></b></td>
        <td>
          <form method="post" style="display:flex;gap:10px;align-items:center">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <label style="display:flex;gap:8px;align-items:center;margin:0">
              <input type="checkbox" name="enabled" <?= ((int)$d['enabled']===1)?'checked':'' ?>>
              <span class="muted">on</span>
            </label>
        </td>
        <td>
            <input name="sort_order" type="number" step="1" value="<?= h($d['sort_order']) ?>" style="width:90px">
        </td>
        <td style="white-space:nowrap">
            <button class="btn" type="submit">Save</button>
          </form>

          <form method="post" style="display:inline-block" onsubmit="return confirm('Delete direction?')">
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
            <button class="pill" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
