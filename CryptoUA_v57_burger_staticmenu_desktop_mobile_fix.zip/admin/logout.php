<?php
require_once __DIR__ . '/../helpers.php';
session_start();
audit('LOGOUT', []);
session_destroy();
header('Location: /admin/index.php');
