<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

// ===== Fixed blocks (present on the page) =====
$fixedBlocks = [
  'hero' => 'Hero',
  'rates' => 'Calculator (right column)',
  'advantages' => 'Advantages',
  'how' => 'How it works',
  'limits' => 'Limits',
  'reviews' => 'Reviews',
  'partners' => 'Partners',
  'faq' => 'FAQ',
  'contacts' => 'Contacts',
  'miniCard' => 'Mini data card',
];

// Alias for legacy code
$defaultBlocks = $fixedBlocks;

function norm_arr($v): array {
  if(is_string($v)){
    $j = json_decode($v, true);
    $v = $j;
  }
  return is_array($v) ? $v : [];
}

// Merge custom blocks
$custom_blocks = norm_arr(setting_get('custom_blocks', []));
foreach($custom_blocks as $cb){
  if(!is_array($cb)) continue;
  $cid = (string)($cb['id'] ?? '');
  if($cid==='') continue;
  $bid = 'cb_'.$cid;
  $label = (string)($cb['title_uk'] ?? 'Custom block');
  $defaultBlocks[$bid] = $label ?: 'Custom block';
}

function norm_styles($v): array {
  $v = norm_arr($v);
  $out = [];
  foreach($v as $k=>$s){
    if(!is_array($s)) continue;
    $id = (string)$k;
    if($id==='') continue;
    $out[$id] = [
      'bg' => (string)($s['bg'] ?? ''),
      'text' => (string)($s['text'] ?? ''),
      'color' => (string)($s['color'] ?? ''),
      'radius' => (string)($s['radius'] ?? ''),
      'pad' => (string)($s['pad'] ?? ''),
      'shadow' => (string)($s['shadow'] ?? ''),
      'fs' => (string)($s['fs'] ?? ''),
      'w' => (string)($s['w'] ?? ''),
    ];
  }
  return $out;
}

function norm_layout($v): array {
  if(is_string($v)) $v = json_decode($v, true);
  if(!is_array($v)) $v = [];
  $out = ['header'=>[], 'body'=>[], 'footer'=>[]];
  foreach(['header','body','footer'] as $k){
    $arr = $v[$k] ?? [];
    if(is_string($arr)) $arr = json_decode($arr, true);
    if(!is_array($arr)) $arr = [];
    $tmp = [];
    foreach($arr as $id){
      $id = (string)$id;
      if($id!=='' && !in_array($id, $tmp, true)) $tmp[] = $id;
    }
    $out[$k] = $tmp;
  }
  return $out;
}

function layout_region_of(array $layout, string $id): string {
  foreach(['header','body','footer'] as $k){
    if(in_array($id, $layout[$k] ?? [], true)) return $k;
  }
  return 'body';
}

function layout_remove(array $layout, string $id): array {
  foreach(['header','body','footer'] as $k){
    $layout[$k] = array_values(array_filter($layout[$k] ?? [], fn($x)=> (string)$x !== $id));
  }
  return $layout;
}

function layout_add(array $layout, string $id, string $region): array {
  $region = in_array($region, ['header','body','footer'], true) ? $region : 'body';
  $layout = layout_remove($layout, $id);
  $layout[$region][] = $id;
  return $layout;
}

function norm_layout_complete(array $layout, array $allBlocks): array {
  $layout = norm_layout($layout);
  // remove unknown
  foreach(['header','body','footer'] as $k){
    $layout[$k] = array_values(array_filter($layout[$k], fn($id)=>isset($allBlocks[(string)$id])));
  }
  // ensure every block exists in some region (default body)
  foreach(array_keys($allBlocks) as $id){
    if(layout_region_of($layout, (string)$id)==='body' && !in_array((string)$id, $layout['body'], true)
       && !in_array((string)$id, $layout['header'], true) && !in_array((string)$id, $layout['footer'], true)){
      $layout['body'][] = (string)$id;
    }
  }
  // de-dup
  $seen=[];
  foreach(['header','body','footer'] as $k){
    $tmp=[];
    foreach($layout[$k] as $id){
      if(isset($seen[$id])) continue;
      $seen[$id]=true;
      $tmp[]=$id;
    }
    $layout[$k]=$tmp;
  }
  return $layout;
}

function save_upload(string $field, string $prefix): ?string {
  if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
  $tmp = $_FILES[$field]['tmp_name'];
  $name = basename($_FILES[$field]['name']);
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if (!in_array($ext, ['png','jpg','jpeg','webp','svg'], true)) return null;
  $fn = $prefix . '_' . date('Ymd_His') . '.' . $ext;
  $dest = __DIR__ . '/../uploads/' . $fn;
  if (!move_uploaded_file($tmp, $dest)) return null;
  return '/uploads/' . $fn;
}

// ===== Load custom blocks =====
$customBlocks = setting_get('home_custom_blocks', []);
if(is_string($customBlocks)) $customBlocks = json_decode($customBlocks, true);
if(!is_array($customBlocks)) $customBlocks = [];

$customMap = [];
foreach($customBlocks as $b){
  if(!is_array($b)) continue;
  $id = (string)($b['id'] ?? '');
  if($id==='') continue;
  $customMap[$id] = $b;
}

// Merge blocks
$allBlocks = $fixedBlocks + array_fill_keys(array_keys($customMap), 'Custom');
foreach($customMap as $id=>$b){
  $label = (string)($b['label'] ?? '');
  if($label!=='') $allBlocks[$id] = $label;
  else {
    $t = (string)($b['type'] ?? 'text');
    $allBlocks[$id] = 'Custom: ' . strtoupper($t);
  }
}

$msg = '';

// ===== Inner orders (cards inside sections) =====
function extract_ids($arr, $key): array {
  $out = [];
  if(!is_array($arr)) return $out;
  foreach($arr as $it){
    if(is_array($it) && !empty($it['_id'])) $out[] = (string)$it['_id'];
  }
  return $out;
}

$blocks_uk = norm_arr(setting_get('blocks_uk', []));
$blocks_en = norm_arr(setting_get('blocks_en', []));

// prefer UK as canonical ids set
$partnersOrder = extract_ids($blocks_uk['partners'] ?? [], '_id');
$reviewsOrder  = extract_ids($blocks_uk['reviews'] ?? [], '_id');
$limitsOrder   = extract_ids($blocks_uk['limits'] ?? [], '_id');
$faqOrder      = extract_ids($blocks_uk['faq'] ?? [], '_id');
$advOrder      = extract_ids($blocks_uk['advantages'] ?? [], '_id');

if($_SERVER['REQUEST_METHOD']==='POST'){
  $action = (string)($_POST['action'] ?? 'save');

  // Add custom block
  if($action==='add_block'){
    $type = (string)($_POST['block_type'] ?? 'text');
    if(!in_array($type, ['text','image','cta'], true)) $type = 'text';
    $id = 'cb_' . bin2hex(random_bytes(4));
    $presetLabel = $type==='cta' ? 'CTA block' : ($type==='image' ? 'Image block' : 'Text block');
    $b = [
      'id'=>$id,
      'type'=>$type,
      'label'=>$presetLabel,
      'title_uk'=> $type==='cta' ? 'Швидка заявка' : ($type==='image' ? 'Блок з зображенням' : 'Текстовий блок'),
      'title_en'=> $type==='cta' ? 'Quick request' : ($type==='image' ? 'Image block' : 'Text block'),
      'text_uk'=> $type==='cta' ? 'Натисни кнопку — оператор підтвердить деталі.' : ($type==='image' ? 'Опис під зображенням (за потреби).' : 'Введи текст…'),
      'text_en'=> $type==='cta' ? 'Press the button — an operator will confirm details.' : ($type==='image' ? 'Caption under the image (optional).' : 'Type text…'),
      'btn_uk'=> 'Відправити заявку',
      'btn_en'=> 'Send request',
      'url'=> '#rates',
      'img'=> '',
      'alt'=> 'image',
      'region'=>'body',
    ];
    $customBlocks[] = $b;
    setting_set('home_custom_blocks', $customBlocks);

    // add to layouts (end of body)
    $ld = norm_layout_complete(setting_get('home_layout_desktop', []), $allBlocks + [$id=>$presetLabel]);
    $lm = norm_layout_complete(setting_get('home_layout_mobile', []),  $allBlocks + [$id=>$presetLabel]);
    $ld['body'][] = $id; $lm['body'][] = $id;
    setting_set('home_layout_desktop', $ld);
    setting_set('home_layout_mobile',  $lm);

    // bump
    setting_set('visual_ver', time());
    audit('HOME_BUILDER_ADD_BLOCK', ['id'=>$id,'type'=>$type]);
    header('Location: /admin/builder.php?added='.$id);
    exit;
  }

  // Delete custom block
  if($action==='delete_block'){
    $del = (string)($_POST['block_id'] ?? '');
    if($del && isset($customMap[$del])){
      $customBlocks = array_values(array_filter($customBlocks, fn($b)=> is_array($b) && (string)($b['id'] ?? '') !== $del));
      setting_set('home_custom_blocks', $customBlocks);

      // remove from layouts
      $ld = norm_layout(setting_get('home_layout_desktop', []));
      $lm = norm_layout(setting_get('home_layout_mobile', []));
      $ld = layout_remove($ld, $del);
      $lm = layout_remove($lm, $del);
      setting_set('home_layout_desktop', $ld);
      setting_set('home_layout_mobile',  $lm);

      // remove styles maps
      $sd = norm_styles(setting_get('home_styles_desktop', [])); unset($sd[$del]); setting_set('home_styles_desktop', $sd);
      $sm = norm_styles(setting_get('home_styles_mobile',  [])); unset($sm[$del]); setting_set('home_styles_mobile',  $sm);

      setting_set('visual_ver', time());
      audit('HOME_BUILDER_DELETE_BLOCK', ['id'=>$del]);
      $msg = 'Deleted';
    }
  }

  if($action==='save'){
    $ld = json_decode((string)($_POST['layout_desktop'] ?? '{}'), true);
    $lm = json_decode((string)($_POST['layout_mobile'] ?? '{}'), true);
    $sd = json_decode((string)($_POST['styles_desktop'] ?? '{}'), true);
    $sm = json_decode((string)($_POST['styles_mobile'] ?? '{}'), true);
    $ed = json_decode((string)($_POST['el_styles_desktop'] ?? '{}'), true);
    $em = json_decode((string)($_POST['el_styles_mobile'] ?? '{}'), true);
    $td = json_decode((string)($_POST['el_texts_desktop'] ?? '{}'), true);
    $tm = json_decode((string)($_POST['el_texts_mobile'] ?? '{}'), true);

    if(!is_array($ld)) $ld = [];
    if(!is_array($lm)) $lm = [];
    if(!is_array($sd)) $sd = [];
    if(!is_array($sm)) $sm = [];
    if(!is_array($ed)) $ed = [];
    if(!is_array($em)) $em = [];
    if(!is_array($td)) $td = [];
    if(!is_array($tm)) $tm = [];

    // Update custom blocks (fields)
    $cbPost = $_POST['cb'] ?? [];
    if(is_array($cbPost)){
      foreach($customBlocks as &$b){
        if(!is_array($b)) continue;
        $id = (string)($b['id'] ?? '');
        if(!$id || !isset($cbPost[$id]) || !is_array($cbPost[$id])) continue;
        $p = $cbPost[$id];

        foreach(['label','title_uk','title_en','text_uk','text_en','btn_uk','btn_en','url','alt'] as $k){
          if(isset($p[$k]) && is_string($p[$k])) $b[$k] = trim($p[$k]);
        }
        if(isset($p['img']) && is_string($p['img'])) $b['img'] = trim($p['img']);
        if(isset($p['region']) && is_string($p['region'])) $b['region'] = in_array($p['region'], ['header','body','footer'], true) ? $p['region'] : 'body';

        // file upload for image
        $fkey = 'cb_img_'.$id;
        if(isset($_FILES[$fkey]) && $_FILES[$fkey]['error']===UPLOAD_ERR_OK){
          $path = save_upload($fkey, 'cb_'.$id);
          if($path) $b['img'] = $path;
        }
      }
      unset($b);
      setting_set('home_custom_blocks', $customBlocks);
    }

    $ld = norm_layout_complete($ld, $allBlocks);
    $lm = norm_layout_complete($lm, $allBlocks);

    // Enforce locked blocks stay in body
    foreach(array_keys($lockedBlocks) as $bid){
      $ld = layout_add($ld, $bid, 'body');
      $lm = layout_add($lm, $bid, 'body');
    }

    $sd = norm_styles($sd);
    $sm = norm_styles($sm);
    $ed = norm_styles($ed);
    $em = norm_styles($em);

    // texts: keep only strings
    $td2 = [];
    foreach($td as $k=>$v){ if(is_string($v)) $td2[(string)$k] = $v; }
    $tm2 = [];
    foreach($tm as $k=>$v){ if(is_string($v)) $tm2[(string)$k] = $v; }

    setting_set('home_layout_desktop', $ld);
    setting_set('home_layout_mobile',  $lm);
    // keep back-compat arrays (body only)
    setting_set('home_order_desktop', $ld['body']);
    setting_set('home_order_mobile',  $lm['body']);

    setting_set('home_styles_desktop', $sd);
    setting_set('home_styles_mobile',  $sm);
    setting_set('home_el_styles_desktop', $ed);
    setting_set('home_el_styles_mobile',  $em);
    setting_set('home_el_texts_desktop', $td2);
    setting_set('home_el_texts_mobile',  $tm2);

    setting_set('visual_ver', time());


  // Save inner orders from builder (advantages/limits/reviews/partners/faq) into blocks_uk & blocks_en
  $pOrder = json_decode((string)($_POST['partners_order'] ?? '[]'), true); if(!is_array($pOrder)) $pOrder=[];
  $rOrder = json_decode((string)($_POST['reviews_order'] ?? '[]'), true);  if(!is_array($rOrder)) $rOrder=[];
  $lOrder = json_decode((string)($_POST['limits_order'] ?? '[]'), true);   if(!is_array($lOrder)) $lOrder=[];
  $fOrder = json_decode((string)($_POST['faq_order'] ?? '[]'), true);      if(!is_array($fOrder)) $fOrder=[];
  $aOrder = json_decode((string)($_POST['adv_order'] ?? '[]'), true);      if(!is_array($aOrder)) $aOrder=[];

  $applyOrder = function($arr, $order){
    if(!is_array($arr)) return $arr;
    $map = [];
    foreach($arr as $it){
      if(is_array($it) && !empty($it['_id'])) $map[(string)$it['_id']] = $it;
    }
    if(!count($map)) return $arr;
    $new=[];
    foreach($order as $id){
      $id=(string)$id;
      if(isset($map[$id])){ $new[]=$map[$id]; unset($map[$id]); }
    }
    foreach($map as $it){ $new[]=$it; }
    return $new;
  };

  foreach(['uk','en'] as $L){
    $bk = norm_arr(setting_get('blocks_'.$L, []));
    if(isset($bk['partners']))   $bk['partners']   = $applyOrder($bk['partners'], $pOrder);
    if(isset($bk['reviews']))    $bk['reviews']    = $applyOrder($bk['reviews'], $rOrder);
    if(isset($bk['limits']))     $bk['limits']     = $applyOrder($bk['limits'], $lOrder);
    if(isset($bk['faq']))        $bk['faq']        = $applyOrder($bk['faq'], $fOrder);
    if(isset($bk['advantages'])) $bk['advantages'] = $applyOrder($bk['advantages'], $aOrder);
    setting_set('blocks_'.$L, $bk);
  }

audit('HOME_BUILDER_SAVE', ['custom_blocks'=>count($customBlocks)]);
    $msg = 'Saved ✅';
  }
}

// ===== Load saved state =====
$layoutDesktop = norm_layout_complete(setting_get('home_layout_desktop', []), $allBlocks);
$layoutMobile  = norm_layout_complete(setting_get('home_layout_mobile',  []), $allBlocks);

$stylesDesktop = norm_styles(setting_get('home_styles_desktop', []));
$stylesMobile  = norm_styles(setting_get('home_styles_mobile',  []));
$elStylesDesktop = norm_styles(setting_get('home_el_styles_desktop', []));
$elStylesMobile  = norm_styles(setting_get('home_el_styles_mobile',  []));
$elTextsDesktop  = norm_arr(setting_get('home_el_texts_desktop', []));
$elTextsMobile   = norm_arr(setting_get('home_el_texts_mobile',  []));

$ver = (int)setting_get('visual_ver', 0);
if($ver<=0) $ver = time();

$selected = (string)($_GET['added'] ?? '');
?>
<div class="container">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0 0 6px">Home Builder</h2>
      <div class="muted">HEADER = окрема смуга під хедером. FOOTER = всередині footerLine.</div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <a class="pill" href="/admin/menu_builder.php">Menu Builder</a>
      <a class="pill" href="/admin/visual.php">Visual theme</a>
    </div>
  </div>

  <?php if($msg): ?><div class="ok" style="margin:12px 0"><?= h($msg) ?></div><?php endif; ?>

  <div class="card" style="margin:14px 0">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
        <input type="hidden" name="action" value="add_block" />
        <button class="btn" name="block_type" value="text" type="submit">+ Text</button>
        <button class="btn" name="block_type" value="image" type="submit">+ Image</button>
        <button class="btn" name="block_type" value="cta" type="submit">+ CTA</button>
      </form>
      <div class="muted">Додані блоки можна перетягувати, міняти region та стилі.</div>
    </div>
  </div>

  <form method="post" id="builderForm" enctype="multipart/form-data">
    <input type="hidden" name="action" value="save" />
    <input type="hidden" name="layout_desktop" id="layoutDesktopInp" value="<?= h(json_encode($layoutDesktop, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="layout_mobile" id="layoutMobileInp" value="<?= h(json_encode($layoutMobile, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="styles_desktop" id="stylesDesktopInp" value="<?= h(json_encode($stylesDesktop, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="styles_mobile" id="stylesMobileInp" value="<?= h(json_encode($stylesMobile, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="el_styles_desktop" id="elStylesDesktopInp" value="<?= h(json_encode($elStylesDesktop, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="el_styles_mobile" id="elStylesMobileInp" value="<?= h(json_encode($elStylesMobile, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="el_texts_desktop" id="elTextsDesktopInp" value="<?= h(json_encode($elTextsDesktop, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="el_texts_mobile" id="elTextsMobileInp" value="<?= h(json_encode($elTextsMobile, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="partners_order" id="partnersOrderInp" value="<?= h(json_encode($partnersOrder, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="reviews_order" id="reviewsOrderInp" value="<?= h(json_encode($reviewsOrder, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="limits_order" id="limitsOrderInp" value="<?= h(json_encode($limitsOrder, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="faq_order" id="faqOrderInp" value="<?= h(json_encode($faqOrder, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />
    <input type="hidden" name="adv_order" id="advOrderInp" value="<?= h(json_encode($advOrder, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>" />



    <div style="display:grid;grid-template-columns:360px 1fr;gap:14px;align-items:start">
      <!-- Left panel -->
      <div class="card" style="padding:12px">
        <div style="display:flex;gap:10px;align-items:center;justify-content:space-between">
          <div style="font-weight:900">Blocks</div>
          <div style="display:flex;gap:8px">
            <button class="btn" type="button" id="deviceDesktopBtn">Desktop</button>
            <button class="btn" type="button" id="deviceMobileBtn">Mobile</button>
          </div>
        </div>

        <div class="muted" style="margin:10px 0 8px">Drag блоки між HEADER / BODY / FOOTER. Клік по блоку у превʼю → редагування.</div>

        <div class="regionWrap" id="regionsWrap">
          <?php foreach(['header'=>'HEADER','body'=>'BODY','footer'=>'FOOTER'] as $rk=>$rLabel): ?>
            <div class="card" style="padding:10px;margin:10px 0;background:rgba(255,255,255,.03)" data-region-box="<?= h($rk) ?>">
              <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
                <div style="font-weight:900"><?= h($rLabel) ?></div>
                <div class="muted" style="font-size:12px"><?= $rk==='header'?'під хедером':($rk==='footer'?'в footerLine':'основний контент') ?></div>
              </div>
              <div class="blockList" data-region-list="<?= h($rk) ?>"></div>
            </div>
          <?php endforeach; ?>
        </div>

        <div style="margin-top:12px;display:flex;gap:10px;flex-wrap:wrap">
          <button class="btnPrimary" type="submit">Save</button>
          <a class="btn" href="/" target="_blank">Open site</a>
        </div>

        <hr style="border:0;border-top:1px solid rgba(255,255,255,.08);margin:14px 0">

        <div id="editPanel">
          <div class="muted">Select a block / element in preview.</div>
        </div>
      </div>

      <!-- Preview -->
      <div class="card" style="padding:0;overflow:hidden">
        <iframe id="preview" src="/?builder=1&amp;lang=uk&amp;v=<?= h((string)$ver) ?>" style="width:100%;height:78vh;border:0"></iframe>
      </div>
    </div>

    <!-- Hidden editors (server-rendered) -->
    <div style="display:none">
      <?php foreach($allBlocks as $bid=>$blabel):
        $isCustom = isset($customMap[$bid]);
        $b = $isCustom ? $customMap[$bid] : null;
      ?>
      <div class="blockEditor" data-editor="<?= h($bid) ?>">
        <div style="font-weight:900;margin-bottom:8px"><?= h($blabel) ?></div>

        <label class="muted" style="display:block;margin:8px 0 6px">Region</label>
        <select data-field="region" data-block="<?= h($bid) ?>" <?= isset($lockedBlocks[$bid])?'disabled':'' ?> style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff">
          <option value="header">HEADER</option>
          <option value="body">BODY</option>
          <option value="footer">FOOTER</option>
        </select>
        <?php if(isset($lockedBlocks[$bid])): ?><div class="muted" style="margin-top:6px;font-size:12px">This block is locked (layout safe).</div><?php endif; ?>

        <label class="muted" style="display:block;margin:12px 0 6px">Block style</label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <input data-field="bg" data-block="<?= h($bid) ?>" placeholder="Background (rgba/gradient)" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-field="text" data-block="<?= h($bid) ?>" placeholder="Text color" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-field="radius" data-block="<?= h($bid) ?>" placeholder="Radius (px)" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-field="pad" data-block="<?= h($bid) ?>" placeholder="Padding (px)" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
        </div>
        <input data-field="shadow" data-block="<?= h($bid) ?>" placeholder="Shadow (css)" style="margin-top:8px;width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />

        <?php if($isCustom): ?>
          <label class="muted" style="display:block;margin:12px 0 6px">Label (admin)</label>
          <input name="cb[<?= h($bid) ?>][label]" value="<?= h((string)($b['label'] ?? '')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />

          <input type="hidden" name="cb[<?= h($bid) ?>][region]" value="<?= h((string)($b['region'] ?? 'body')) ?>" data-cb-region="<?= h($bid) ?>" />

          <label class="muted" style="display:block;margin:12px 0 6px">Title UK</label>
          <input name="cb[<?= h($bid) ?>][title_uk]" value="<?= h((string)($b['title_uk'] ?? '')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />

          <label class="muted" style="display:block;margin:12px 0 6px">Title EN</label>
          <input name="cb[<?= h($bid) ?>][title_en]" value="<?= h((string)($b['title_en'] ?? '')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />

          <label class="muted" style="display:block;margin:12px 0 6px">Text UK</label>
          <textarea name="cb[<?= h($bid) ?>][text_uk]" style="width:100%;min-height:88px;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff"><?= h((string)($b['text_uk'] ?? '')) ?></textarea>

          <label class="muted" style="display:block;margin:12px 0 6px">Text EN</label>
          <textarea name="cb[<?= h($bid) ?>][text_en]" style="width:100%;min-height:88px;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff"><?= h((string)($b['text_en'] ?? '')) ?></textarea>

          <?php $t = (string)($b['type'] ?? 'text'); if($t==='cta'): ?>
            <label class="muted" style="display:block;margin:12px 0 6px">Button UK</label>
            <input name="cb[<?= h($bid) ?>][btn_uk]" value="<?= h((string)($b['btn_uk'] ?? '')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
            <label class="muted" style="display:block;margin:12px 0 6px">Button EN</label>
            <input name="cb[<?= h($bid) ?>][btn_en]" value="<?= h((string)($b['btn_en'] ?? '')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
            <label class="muted" style="display:block;margin:12px 0 6px">URL</label>
            <input name="cb[<?= h($bid) ?>][url]" value="<?= h((string)($b['url'] ?? '#')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <?php endif; ?>

          <?php if($t==='image'): ?>
            <label class="muted" style="display:block;margin:12px 0 6px">Image</label>
            <input type="file" name="cb_img_<?= h($bid) ?>" accept=".png,.jpg,.jpeg,.webp,.svg" />
            <div class="muted" style="margin:8px 0 6px">…or URL</div>
            <input name="cb[<?= h($bid) ?>][img]" value="<?= h((string)($b['img'] ?? '')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
            <label class="muted" style="display:block;margin:12px 0 6px">ALT</label>
            <input name="cb[<?= h($bid) ?>][alt]" value="<?= h((string)($b['alt'] ?? 'image')) ?>" style="width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <?php endif; ?>

          <div style="margin-top:14px">
            <button class="btn" type="button" data-delete="<?= h($bid) ?>">Delete block</button>
          </div>
        <?php endif; ?>

        <hr style="border:0;border-top:1px solid rgba(255,255,255,.08);margin:14px 0">
        <div class="muted">Element styles/text: click an element in preview (data-el) to edit.</div>
      </div>
      <?php endforeach; ?>

      <div class="elementEditor" id="elementEditorTpl">
        <div style="font-weight:900;margin-bottom:8px">Element</div>
        <label class="muted" style="display:block;margin:8px 0 6px">Text</label>
        <textarea data-el-field="text" style="width:100%;min-height:70px;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff"></textarea>
        <label class="muted" style="display:block;margin:12px 0 6px">Style</label>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
          <input data-el-field="bg" placeholder="Background" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-el-field="color" placeholder="Color" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-el-field="radius" placeholder="Radius px" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-el-field="pad" placeholder="Padding px" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-el-field="fs" placeholder="Font size px" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
          <input data-el-field="w" placeholder="Font weight" style="padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
        </div>
        <input data-el-field="shadow" placeholder="Shadow" style="margin-top:8px;width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff" />
      </div>
    </div>
  </form>
</div>

<style>
.blockList{display:flex;flex-direction:column;gap:8px;margin-top:10px}
.blockItem{
  display:flex;align-items:center;justify-content:space-between;gap:10px;
  padding:10px 10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.03);cursor:grab;
}
.blockItem .title{font-weight:900}
.blockItem .tag{font-size:11px;padding:4px 8px;border-radius:999px;border:1px solid rgba(255,255,255,.14);opacity:.85}
.blockItem.dragging{opacity:.45}
.blockItem.dropTarget{outline:2px solid rgba(120,255,180,.4)}
</style>

<script>
(function(){
  var iframe = document.getElementById('preview');
  var editPanel = document.getElementById('editPanel');

  var device = 'desktop';
  var layoutDesktop = JSON.parse(document.getElementById('layoutDesktopInp').value || '{}');
  var layoutMobile  = JSON.parse(document.getElementById('layoutMobileInp').value  || '{}');

  var stylesDesktop = JSON.parse(document.getElementById('stylesDesktopInp').value || '{}');
  var stylesMobile  = JSON.parse(document.getElementById('stylesMobileInp').value  || '{}');
  var elStylesDesktop = JSON.parse(document.getElementById('elStylesDesktopInp').value || '{}');
  var elStylesMobile  = JSON.parse(document.getElementById('elStylesMobileInp').value  || '{}');
  var elTextsDesktop  = JSON.parse(document.getElementById('elTextsDesktopInp').value  || '{}');
  var elTextsMobile   = JSON.parse(document.getElementById('elTextsMobileInp').value   || '{}');

  // Blocks list source
  var allBlocks = <?= json_encode(array_keys($allBlocks), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  var labels = <?= json_encode($allBlocks, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  var locked = <?= json_encode(array_keys($lockedBlocks), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  function isLocked(id){ return locked.indexOf(id)>=0; }

  function activeLayout(){ return device==='mobile' ? layoutMobile : layoutDesktop; }
  function setActiveLayout(v){
    if(device==='mobile'){ layoutMobile = v; document.getElementById('layoutMobileInp').value = JSON.stringify(v); }
    else { layoutDesktop = v; document.getElementById('layoutDesktopInp').value = JSON.stringify(v); }
  }
  function activeStyles(){ return device==='mobile' ? stylesMobile : stylesDesktop; }
  function setActiveStyles(v){
    if(device==='mobile'){ stylesMobile=v; document.getElementById('stylesMobileInp').value = JSON.stringify(v); }
    else { stylesDesktop=v; document.getElementById('stylesDesktopInp').value = JSON.stringify(v); }
  }
  function activeElStyles(){ return device==='mobile' ? elStylesMobile : elStylesDesktop; }
  function setActiveElStyles(v){
    if(device==='mobile'){ elStylesMobile=v; document.getElementById('elStylesMobileInp').value = JSON.stringify(v); }
    else { elStylesDesktop=v; document.getElementById('elStylesDesktopInp').value = JSON.stringify(v); }
  }
  function activeElTexts(){ return device==='mobile' ? elTextsMobile : elTextsDesktop; }
  function setActiveElTexts(v){
    if(device==='mobile'){ elTextsMobile=v; document.getElementById('elTextsMobileInp').value = JSON.stringify(v); }
    else { elTextsDesktop=v; document.getElementById('elTextsDesktopInp').value = JSON.stringify(v); }
  }

  function postApply(){
    try{
      iframe.contentWindow.postMessage({
        type:'cryptoua_builder_apply',
        layout: activeLayout(),
        blockStyles: activeStyles(),
        elStyles: activeElStyles(),
        elTexts: activeElTexts()
      }, '*');
    }catch(e){}
  }

  function renderLists(){
    var layout = activeLayout();
    ['header','body','footer'].forEach(function(region){
      var box = document.querySelector('[data-region-list="'+region+'"]');
      if(!box) return;
      box.innerHTML = '';
      (layout[region] || []).forEach(function(id){
        if(allBlocks.indexOf(id)<0) return;
        var item = document.createElement('div');
        item.className = 'blockItem';
        item.draggable = true;
        item.dataset.id = id;
        item.dataset.region = region;
        item.innerHTML = '<div class="title">'+(labels[id]||id)+'</div><div class="tag">'+region.toUpperCase()+'</div>';
        if(isLocked(id)){ item.style.opacity = '.6'; item.style.cursor='not-allowed'; item.draggable=false; item.querySelector('.tag').textContent='LOCKED'; }
        item.addEventListener('click', function(){
          selectBlock(id);
          try{ iframe.contentWindow.postMessage({type:'cryptoua_builder_select_block', id:id}, '*'); }catch(e){}
        });
        box.appendChild(item);
      });

      // DnD
      var dragId = null;
      box.addEventListener('dragstart', function(e){
        var t = e.target.closest('.blockItem'); if(!t) return;
        dragId = t.dataset.id;
        t.classList.add('dragging');
        e.dataTransfer.setData('text/plain', dragId);
      });
      box.addEventListener('dragend', function(e){
        var t = e.target.closest('.blockItem'); if(t) t.classList.remove('dragging');
        dragId = null;
        box.querySelectorAll('.dropTarget').forEach(function(x){x.classList.remove('dropTarget');});
      });
      box.addEventListener('dragover', function(e){
        e.preventDefault();
        var t = e.target.closest('.blockItem'); if(t) t.classList.add('dropTarget');
      });
      box.addEventListener('dragleave', function(e){
        var t = e.target.closest('.blockItem'); if(t) t.classList.remove('dropTarget');
      });
      box.addEventListener('drop', function(e){
        e.preventDefault();
        var id = e.dataTransfer.getData('text/plain');
        if(!id || isLocked(id)) return;
        var layout = activeLayout();
        // remove
        ['header','body','footer'].forEach(function(r){
          layout[r] = (layout[r]||[]).filter(function(x){ return String(x)!==String(id); });
        });
        // insert
        var before = e.target.closest('.blockItem');
        var list = layout[region] || [];
        if(before && before.dataset && before.dataset.id){
          var idx = list.indexOf(before.dataset.id);
          if(idx<0) idx = list.length;
          list.splice(idx, 0, id);
        } else {
          list.push(id);
        }
        layout[region] = list;
        setActiveLayout(layout);
        renderLists();
        postApply();
      });
    });
  }

  function editorForBlock(id){
    var el = document.querySelector('.blockEditor[data-editor="'+id+'"]');
    return el ? el.cloneNode(true) : null;
  }

  function fillBlockEditor(node, id){
    var layout = activeLayout();
    var region = (function(){
      for(var k in layout){ if((layout[k]||[]).indexOf(id)>=0) return k; }
      return 'body';
    })();
    var sel = node.querySelector('select[data-field="region"]');
    if(sel){
      sel.value = region;
      sel.addEventListener('change', function(){
        var r = sel.value;
        if(isLocked(id)) return;
        var L = activeLayout();
        ['header','body','footer'].forEach(function(k){
          L[k] = (L[k]||[]).filter(function(x){ return String(x)!==String(id); });
        });
        (L[r] = L[r] || []).push(id);
        setActiveLayout(L);
        // sync hidden input for custom block region too
        var hid = document.querySelector('input[data-cb-region="'+id+'"]');
        if(hid) hid.value = r;
        renderLists();
        postApply();
      });
    }

    // delete
    node.querySelectorAll('[data-delete]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var bid = btn.getAttribute('data-delete');
        if(!bid) return;
        if(!confirm('Delete block '+bid+'?')) return;
        var f = document.createElement('form');
        f.method='post';
        f.innerHTML = '<input type="hidden" name="action" value="delete_block"><input type="hidden" name="block_id" value="'+bid+'">';
        document.body.appendChild(f); f.submit();
      });
    });

    // block styles inputs
    var styles = activeStyles();
    var st = styles[id] || {};
    ['bg','text','radius','pad','shadow'].forEach(function(k){
      var inp = node.querySelector('[data-field="'+k+'"][data-block="'+id+'"]');
      if(!inp) return;
      inp.value = st[k] || '';
      inp.addEventListener('input', function(){
        var S = activeStyles();
        S[id] = S[id] || {};
        S[id][k] = inp.value;
        setActiveStyles(S);
        postApply();
      });
    });
  }

  function showElementEditor(elid){
    var tpl = document.getElementById('elementEditorTpl');
    var node = tpl.cloneNode(true);
    node.id = '';
    node.style.display = 'block';
    node.dataset.elEditor = elid;

    var texts = activeElTexts();
    var est = activeElStyles();
    var curText = (texts && texts[elid]) ? texts[elid] : '';
    var curStyle = (est && est[elid]) ? est[elid] : {};

    node.querySelector('[data-el-field="text"]').value = curText;

    ['bg','color','radius','pad','shadow','fs','w'].forEach(function(k){
      var inp = node.querySelector('[data-el-field="'+k+'"]');
      if(inp) inp.value = curStyle[k] || '';
    });

    node.querySelector('[data-el-field="text"]').addEventListener('input', function(e){
      var T = activeElTexts(); T[elid] = e.target.value; setActiveElTexts(T); postApply();
    });
    ['bg','color','radius','pad','shadow','fs','w'].forEach(function(k){
      var inp = node.querySelector('[data-el-field="'+k+'"]');
      if(!inp) return;
      inp.addEventListener('input', function(){
        var E = activeElStyles();
        E[elid] = E[elid] || {};
        E[elid][k] = inp.value;
        setActiveElStyles(E);
        postApply();
      });
    });

    editPanel.innerHTML = '';
    editPanel.appendChild(node);
  }

  function selectBlock(id){
    var ed = editorForBlock(id);
    editPanel.innerHTML = '';
    if(!ed){
      editPanel.innerHTML = '<div class="muted">No editor for block</div>';
      return;
    }
    ed.style.display = 'block';
    fillBlockEditor(ed, id);
    editPanel.appendChild(ed);
  }

  // device buttons
  function setDevice(d){
    device = d;
    document.getElementById('deviceDesktopBtn').classList.toggle('btnPrimary', d==='desktop');
    document.getElementById('deviceMobileBtn').classList.toggle('btnPrimary', d==='mobile');
    // resize iframe
    if(d==='mobile'){
      iframe.style.width = '420px';
      iframe.style.maxWidth = '100%';
      iframe.parentElement.style.display='flex';
      iframe.parentElement.style.justifyContent='center';
      iframe.parentElement.style.padding='12px 0';
    } else {
      iframe.style.width = '100%';
      iframe.parentElement.style.display='block';
      iframe.parentElement.style.padding='0';
    }
    renderLists();
    // apply current state
    setTimeout(postApply, 120);
  }
  document.getElementById('deviceDesktopBtn').addEventListener('click', function(){ setDevice('desktop'); });
  document.getElementById('deviceMobileBtn').addEventListener('click', function(){ setDevice('mobile'); });

  // Listen selections from iframe
  window.addEventListener('message', function(ev){
    var d = ev.data || {};
    if(d.type==='cryptoua_builder_select_block' && d.id){
      selectBlock(String(d.id));
    }
    if(d.type==='cryptoua_builder_select_el' && d.id){
      showElementEditor(String(d.id));
    }

    if(d.type === 'cryptoua_builder_reviews_order' && Array.isArray(d.order)){
      document.getElementById('reviewsOrderInp').value = JSON.stringify(d.order.map(String));
      return;
    }
    if(d.type === 'cryptoua_builder_partners_order' && Array.isArray(d.order)){
      document.getElementById('partnersOrderInp').value = JSON.stringify(d.order.map(String));
      return;

    if(d.type === 'cryptoua_builder_limits_order' && Array.isArray(d.order)){
      document.getElementById('limitsOrderInp').value = JSON.stringify(d.order.map(String));
      return;
    }
    if(d.type === 'cryptoua_builder_faq_order' && Array.isArray(d.order)){
      document.getElementById('faqOrderInp').value = JSON.stringify(d.order.map(String));
      return;
    }
    if(d.type === 'cryptoua_builder_adv_order' && Array.isArray(d.order)){
      document.getElementById('advOrderInp').value = JSON.stringify(d.order.map(String));
      return;
    }
    }
  });

  // initial
  setDevice('desktop');

  // Auto select newly added
  var sel = <?= json_encode($selected ?: '', JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
  if(sel){
    setTimeout(function(){ selectBlock(sel); }, 400);
  }

})();
</script>
<?php include __DIR__ . '/_footer.php'; ?>
