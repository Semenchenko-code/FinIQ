<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';
$key = 'blocks_' . $lang;

$blocks = setting_get($key, [
  'hero'=>['title'=>'P2P Crypto ⇄ UAH','lead'=>'Швидкий обмін через операторів. Фіксація курсу на кілька хвилин.'],
  'advantages'=>[
    ['_id'=>'a_speed','title'=>'5–15 хв','text'=>'типова швидкість','icon'=>'round'],
    ['_id'=>'a_dir','title'=>'UAH ⇄ Crypto','text'=>'2 напрямки','icon'=>'square'],
    ['_id'=>'a_support','title'=>'Support','text'=>'оператори 24/7','icon'=>'green'],
  ],
  'limits'=>[ ['title'=>'Мінімум','text'=>'від 2 000 UAH'], ['title'=>'Максимум','text'=>'до 300 000 UAH'], ['title'=>'Час','text'=>'10–30 хв'] ],
  'rules'=>['P2P обмін через операторів','Курс фіксується на N хвилин','AML/перевірки при потребі'],
  'faq'=>[ ['q'=>'Скільки триває обмін?','a'=>'Зазвичай 10–30 хвилин.'], ['q'=>'Чи фіксується курс?','a'=>'Так, після створення заявки на N хвилин.'] ],
  'contacts'=>['telegram'=>'','phone'=>'','email'=>''],
  'footer'=>['line1'=>'CryptoUA • P2P exchange','line2'=>'© '.date('Y')],
  'partners'=>[ ['name'=>'Partner 1','logo'=>''], ['name'=>'Partner 2','logo'=>''], ['name'=>'Partner 3','logo'=>''], ['name'=>'Partner 4','logo'=>''] ],
  'reviews'=>[ ['name'=>'Андрій','tag'=>'USDT → UAH','text'=>'Швидко і без зайвих питань.','avatar'=>''],
               ['name'=>'Олена','tag'=>'UAH → BTC','text'=>'Зручно, курс зафіксували.','avatar'=>''],
               ['name'=>'Ігор','tag'=>'ETH → UAH','text'=>'Оператор завжди на зв’язку.','avatar'=>''] ]
]);

// Ensure stable IDs for reorder
$changedIds = false;
if(isset($blocks['partners']) && is_array($blocks['partners'])){
  foreach($blocks['partners'] as $i=>$p){
    if(!is_array($p)) $p = ['name'=>'','logo'=>''];
    if(empty($p['_id'])){
      $p['_id'] = 'p_' . substr(bin2hex(random_bytes(6)),0,10);
      $blocks['partners'][$i] = $p;
      $changedIds = true;
    }
  }
}
if(isset($blocks['reviews']) && is_array($blocks['reviews'])){
  foreach($blocks['reviews'] as $i=>$r){
    if(!is_array($r)) $r = ['name'=>'','tag'=>'','text'=>'','avatar'=>''];
    if(empty($r['_id'])){
      $r['_id'] = 'r_' . substr(bin2hex(random_bytes(6)),0,10);
      $blocks['reviews'][$i] = $r;
      $changedIds = true;
    }
  }
}

if(isset($blocks['limits']) && is_array($blocks['limits'])){
  foreach($blocks['limits'] as $i=>$c){
    if(!is_array($c)) $c = ['title'=>'','text'=>''];
    if(empty($c['_id'])){
      $c['_id'] = 'l_' . substr(bin2hex(random_bytes(6)),0,10);
      $blocks['limits'][$i] = $c;
      $changedIds = true;
    }
  }
}
if(isset($blocks['faq']) && is_array($blocks['faq'])){
  foreach($blocks['faq'] as $i=>$f){
    if(!is_array($f)) $f = ['q'=>'','a'=>''];
    if(empty($f['_id'])){
      $f['_id'] = 'f_' . substr(bin2hex(random_bytes(6)),0,10);
      $blocks['faq'][$i] = $f;
      $changedIds = true;
    }
  }

if(isset($blocks['advantages']) && is_array($blocks['advantages'])){
  foreach($blocks['advantages'] as $i=>$a){
    if(!is_array($a)) $a = ['title'=>'','text'=>'','icon'=>'round'];
    if(empty($a['_id'])){
      $a['_id'] = 'a_' . substr(bin2hex(random_bytes(6)),0,10);
      $blocks['advantages'][$i] = $a;
      $changedIds = true;
    }
  }
}
}
if($changedIds){
  // persist ids silently
  setting_set($key, $blocks);
}
$theme = setting_get('theme', ['accent'=>'#7c5cff','accent2'=>'#23d5ab','bg'=>'#0b1020','panel'=>'#0f1730','radius'=>18]);
$homeDesign = setting_get('home_design', ['starsTile'=>'/assets/stars-tile.png','bgFxOpacity'=>1]);
$homeSections = setting_get('home_sections', ['limits'=>1,'reviews'=>1,'partners'=>1,'faq'=>1]);


$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $blocks['hero']['title'] = trim($_POST['hero_title'] ?? '');
  $blocks['hero']['lead']  = trim($_POST['hero_lead'] ?? '');

  $blocks['limits'] = [];
  for($i=0;$i<8;$i++){
    $t = trim($_POST["lim_title_$i"] ?? '');
    $x = trim($_POST["lim_text_$i"] ?? '');
    if($t!=='' || $x!=='') $blocks['limits'][] = ['title'=>$t,'text'=>$x];
  }

  $rulesRaw = trim($_POST['rules'] ?? '');
  $blocks['rules'] = array_values(array_filter(array_map('trim', preg_split("/\r?\n/", $rulesRaw))));

  $blocks['faq'] = [];
  for($i=0;$i<12;$i++){
    $q = trim($_POST["faq_q_$i"] ?? '');
    $a = trim($_POST["faq_a_$i"] ?? '');
    if($q!=='' || $a!=='') $blocks['faq'][] = ['q'=>$q,'a'=>$a];
  }

  $blocks['contacts'] = [
    'telegram'=>trim($_POST['c_telegram'] ?? ''),
    'phone'=>trim($_POST['c_phone'] ?? ''),
    'email'=>trim($_POST['c_email'] ?? ''),
  ];

  $blocks['footer'] = [
    'line1'=>trim($_POST['f1'] ?? ''),
    'line2'=>trim($_POST['f2'] ?? ''),
  ];

  // Partners (reorder + values)
  $pOrder = json_decode((string)($_POST['partners_order'] ?? '[]'), true);
  if(!is_array($pOrder)) $pOrder = [];
  $pMap = [];
  foreach(($blocks['partners'] ?? []) as $p){
    if(!is_array($p)) continue;
    $pid = (string)($p['_id'] ?? '');
    if($pid!=='') $pMap[$pid] = $p;
  }
  $newP = [];
  foreach($pOrder as $pid){
    $pid=(string)$pid;
    if(!isset($pMap[$pid])) continue;
    $p = $pMap[$pid];
    $p['name'] = trim($_POST['p_name_'.$pid] ?? ($p['name'] ?? ''));
    $newP[] = $p;
    unset($pMap[$pid]);
  }
  foreach($pMap as $pid=>$p){
    $p['name'] = trim($_POST['p_name_'.$pid] ?? ($p['name'] ?? ''));
    $newP[] = $p;
  }
  $blocks['partners'] = $newP;

  // Reviews (reorder + values)
  $rOrder = json_decode((string)($_POST['reviews_order'] ?? '[]'), true);
  if(!is_array($rOrder)) $rOrder = [];
  $rMap = [];
  foreach(($blocks['reviews'] ?? []) as $r){
    if(!is_array($r)) continue;
    $rid = (string)($r['_id'] ?? '');
    if($rid!=='') $rMap[$rid] = $r;
  }
  $newR = [];
  foreach($rOrder as $rid){
    $rid=(string)$rid;
    if(!isset($rMap[$rid])) continue;
    $r = $rMap[$rid];
    $r['name'] = trim($_POST['r_name_'.$rid] ?? ($r['name'] ?? ''));
    $r['tag']  = trim($_POST['r_tag_'.$rid] ?? ($r['tag'] ?? ''));
    $r['text'] = trim($_POST['r_text_'.$rid] ?? ($r['text'] ?? ''));
    $newR[] = $r;
    unset($rMap[$rid]);
  }
  foreach($rMap as $rid=>$r){
    $r['name'] = trim($_POST['r_name_'.$rid] ?? ($r['name'] ?? ''));
    $r['tag']  = trim($_POST['r_tag_'.$rid] ?? ($r['tag'] ?? ''));
    $r['text'] = trim($_POST['r_text_'.$rid] ?? ($r['text'] ?? ''));
    $newR[] = $r;
  }
  $blocks['reviews'] = $newR;

  // Limits (reorder + values)
  $lOrder = json_decode((string)($_POST['limits_order'] ?? '[]'), true);
  if(!is_array($lOrder)) $lOrder = [];
  $lMap = [];
  foreach(($blocks['limits'] ?? []) as $c){
    if(!is_array($c)) continue;
    $lid = (string)($c['_id'] ?? '');
    if($lid!=='') $lMap[$lid] = $c;
  }
  $newL = [];
  foreach($lOrder as $lid){
    $lid=(string)$lid;
    if(!isset($lMap[$lid])) continue;
    $c = $lMap[$lid];
    $c['title'] = trim($_POST['l_title_'.$lid] ?? ($c['title'] ?? ''));
    $c['text']  = trim($_POST['l_text_'.$lid] ?? ($c['text'] ?? ''));
    $newL[] = $c;
    unset($lMap[$lid]);
  }
  foreach($lMap as $lid=>$c){
    $c['title'] = trim($_POST['l_title_'.$lid] ?? ($c['title'] ?? ''));
    $c['text']  = trim($_POST['l_text_'.$lid] ?? ($c['text'] ?? ''));
    $newL[] = $c;
  }
  $blocks['limits'] = $newL;

  // FAQ (reorder + values)
  $fOrder = json_decode((string)($_POST['faq_order'] ?? '[]'), true);
  if(!is_array($fOrder)) $fOrder = [];
  $fMap = [];
  foreach(($blocks['faq'] ?? []) as $f){
    if(!is_array($f)) continue;
    $fid = (string)($f['_id'] ?? '');
    if($fid!=='') $fMap[$fid] = $f;
  }
  $newF = [];
  foreach($fOrder as $fid){
    $fid=(string)$fid;
    if(!isset($fMap[$fid])) continue;
    $f = $fMap[$fid];
    $f['q'] = trim($_POST['f_q_'.$fid] ?? ($f['q'] ?? ''));
    $f['a'] = trim($_POST['f_a_'.$fid] ?? ($f['a'] ?? ''));
    $newF[] = $f;
    unset($fMap[$fid]);
  }
  foreach($fMap as $fid=>$f){
    $f['q'] = trim($_POST['f_q_'.$fid] ?? ($f['q'] ?? ''));
    $f['a'] = trim($_POST['f_a_'.$fid] ?? ($f['a'] ?? ''));
    $newF[] = $f;
  }
  $blocks['faq'] = $newF;



  setting_set($key, $blocks);
  // Theme / Design / Visibility (global, not per-language)
  $theme['accent']  = trim($_POST['t_accent'] ?? $theme['accent']);
  $theme['accent2'] = trim($_POST['t_accent2'] ?? $theme['accent2']);
  $theme['bg']      = trim($_POST['t_bg'] ?? $theme['bg']);
  $theme['panel']   = trim($_POST['t_panel'] ?? $theme['panel']);
  $theme['radius']  = (int)($_POST['t_radius'] ?? $theme['radius']);

  $homeDesign['starsTile'] = trim($_POST['t_stars'] ?? $homeDesign['starsTile']);
  $homeDesign['bgFxOpacity'] = (float)($_POST['t_bgfx_opacity'] ?? $homeDesign['bgFxOpacity']);

  $homeSections = [
    'limits'   => isset($_POST['s_limits']) ? 1 : 0,
    'reviews'  => isset($_POST['s_reviews']) ? 1 : 0,
    'partners' => isset($_POST['s_partners']) ? 1 : 0,
    'faq'      => isset($_POST['s_faq']) ? 1 : 0
  ];

  setting_set('theme', $theme);
  setting_set('home_design', $homeDesign);
  setting_set('home_sections', $homeSections);

  audit('CONTENT_UPDATE', ['lang'=>$lang]);
  $ok='Збережено ✅';
}

?><div class="card">
  <h2 style="margin:0 0 6px">Content (<?= h(strtoupper($lang)) ?>)</h2>
  <div class="muted">Редагування блоків полями (без HTML). Зображення — у Media.</div>
</div>

<div class="card">
  <div style="display:flex;gap:10px">
    <a class="pill" href="/admin/content.php?lang=uk">UA</a>
    <a class="pill" href="/admin/content.php?lang=en">EN</a>
    <a class="pill" href="/admin/media.php?lang=<?= h($lang) ?>">Media</a>
  </div>
</div>

<div class="card">
<form method="post">
  <h3 style="margin:0 0 8px">Theme & Blocks visibility</h3>
  <div class="row">
    <div><label class="muted">Accent (purple)</label><input name="t_accent" value="<?= h($theme['accent'] ?? '') ?>" placeholder="#7c5cff"></div>
    <div><label class="muted">Accent 2 (green)</label><input name="t_accent2" value="<?= h($theme['accent2'] ?? '') ?>" placeholder="#23d5ab"></div>
  </div>
  <div class="row">
    <div><label class="muted">Background</label><input name="t_bg" value="<?= h($theme['bg'] ?? '') ?>" placeholder="#0b1020"></div>
    <div><label class="muted">Panel</label><input name="t_panel" value="<?= h($theme['panel'] ?? '') ?>" placeholder="#0f1730"></div>
  </div>
  <div class="row">
    <div><label class="muted">Radius (8–32)</label><input name="t_radius" type="number" min="8" max="32" value="<?= h($theme['radius'] ?? 18) ?>"></div>
    <div><label class="muted">Stars tile (URL/path)</label><input name="t_stars" value="<?= h($homeDesign['starsTile'] ?? '/assets/stars-tile.png') ?>"></div>
  </div>
  <div class="row">
    <div><label class="muted">Background FX opacity (0.2–1.5)</label><input name="t_bgfx_opacity" type="number" step="0.05" min="0.2" max="1.5" value="<?= h($homeDesign['bgFxOpacity'] ?? 1) ?>"></div>
    <div>
      <label class="muted">Show sections</label>
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:8px">
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="s_limits" <?= ((int)($homeSections['limits']??1)===1)?'checked':''; ?> style="width:auto"> Limits</label>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="s_reviews" <?= ((int)($homeSections['reviews']??1)===1)?'checked':''; ?> style="width:auto"> Reviews</label>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="s_partners" <?= ((int)($homeSections['partners']??1)===1)?'checked':''; ?> style="width:auto"> Partners</label>
        <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="s_faq" <?= ((int)($homeSections['faq']??1)===1)?'checked':''; ?> style="width:auto"> FAQ</label>
      </div>
    </div>
  </div>

  <div style="height:18px"></div>

  <h3 style="margin:0 0 8px">Hero</h3>
  <div class="row">
    <div><label class="muted">Title</label><input name="hero_title" value="<?= h($blocks['hero']['title'] ?? '') ?>"></div>
    <div><label class="muted">Lead</label><input name="hero_lead" value="<?= h($blocks['hero']['lead'] ?? '') ?>"></div>
  </div>

  <div style="height:14px"></div>
  <h3 style="margin:0 0 8px">Limits</h3>
  <?php for($i=0;$i<8;$i++): $it=$blocks['limits'][$i] ?? ['title'=>'','text'=>'']; ?>
    <div class="row">
      <div><input name="lim_title_<?= $i ?>" placeholder="Title" value="<?= h($it['title']) ?>"></div>
      <div><input name="lim_text_<?= $i ?>" placeholder="Text" value="<?= h($it['text']) ?>"></div>
    </div>
    <div style="height:8px"></div>
  <?php endfor; ?>

  <div style="height:14px"></div>
  <h3 style="margin:0 0 8px">Rules (1 per line)</h3>
  <textarea name="rules"><?php foreach(($blocks['rules'] ?? []) as $r) echo h($r)."\n"; ?></textarea>

  <div style="height:14px"></div>
  <h3 style="margin:0 0 8px">FAQ</h3>
  <?php for($i=0;$i<12;$i++): $it=$blocks['faq'][$i] ?? ['q'=>'','a'=>'']; ?>
    <div class="row">
      <div><input name="faq_q_<?= $i ?>" placeholder="Question" value="<?= h($it['q']) ?>"></div>
      <div><input name="faq_a_<?= $i ?>" placeholder="Answer" value="<?= h($it['a']) ?>"></div>
    </div>
    <div style="height:8px"></div>
  <?php endfor; ?>

  <div style="height:14px"></div>
  <h3 style="margin:0 0 8px">Contacts</h3>
  <div class="row">
    <div><label class="muted">Telegram</label><input name="c_telegram" value="<?= h($blocks['contacts']['telegram'] ?? '') ?>"></div>
    <div><label class="muted">Phone</label><input name="c_phone" value="<?= h($blocks['contacts']['phone'] ?? '') ?>"></div>
  </div>
  <div style="height:10px"></div>
  <div><label class="muted">Email</label><input name="c_email" value="<?= h($blocks['contacts']['email'] ?? '') ?>"></div>

  <div style="height:14px"></div>
  <h3 style="margin:0 0 8px">Partners / Reviews (drag to reorder)</h3>
  <input type="hidden" name="partners_order" id="partnersOrder" value="" />
  <input type="hidden" name="reviews_order" id="reviewsOrder" value="" />
  <div class="row">
    <div>
      <label class="muted">Partners</label>
      <div id="partnersList" style="display:flex;flex-direction:column;gap:10px">
        <?php foreach(($blocks['partners'] ?? []) as $p): $pid = (string)($p['_id'] ?? ''); ?>
          <div class="card" style="padding:10px" draggable="true" data-partner="<?= h($pid) ?>">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
              <strong style="font-size:13px">Partner</strong>
              <span class="muted" style="font-size:12px;cursor:grab">⋮⋮</span>
            </div>
            <input name="p_name_<?= h($pid) ?>" value="<?= h($p['name'] ?? '') ?>" placeholder="Partner name" style="margin-top:8px">
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <div>
      <label class="muted">Reviews</label>
      <div id="reviewsList" style="display:flex;flex-direction:column;gap:10px">
        <?php foreach(($blocks['reviews'] ?? []) as $r): $rid = (string)($r['_id'] ?? ''); ?>
          <div class="card" style="padding:10px" draggable="true" data-review="<?= h($rid) ?>">
            <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
              <strong style="font-size:13px">Review</strong>
              <span class="muted" style="font-size:12px;cursor:grab">⋮⋮</span>
            </div>
            <input name="r_name_<?= h($rid) ?>" value="<?= h($r['name'] ?? '') ?>" placeholder="Name" style="margin-top:8px">
            <input name="r_tag_<?= h($rid) ?>"  value="<?= h($r['tag'] ?? '') ?>" placeholder="Tag" style="margin-top:8px">
            <input name="r_text_<?= h($rid) ?>" value="<?= h($r['text'] ?? '') ?>" placeholder="Text" style="margin-top:8px">
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <script>
  (function(){
    function makeDnD(listEl, attr, hidden){
      if(!listEl || !hidden) return;
      var dragId = null;
      listEl.addEventListener('dragstart', function(e){
        var it = e.target.closest('['+attr+']');
        if(!it) return;
        dragId = it.getAttribute(attr);
        try{ e.dataTransfer.setData('text/plain', dragId); }catch(err){}
        it.style.opacity = '0.6';
      });
      listEl.addEventListener('dragend', function(e){
        var it = e.target.closest('['+attr+']');
        if(it) it.style.opacity = '1';
        dragId = null;
      });
      listEl.addEventListener('dragover', function(e){
        if(!dragId) return;
        var it = e.target.closest('['+attr+']');
        if(!it) return;
        e.preventDefault();
      });
      listEl.addEventListener('drop', function(e){
        if(!dragId) return;
        var target = e.target.closest('['+attr+']');
        if(!target) return;
        e.preventDefault();
        var tid = target.getAttribute(attr);
        if(!tid || tid===dragId) return;
        var items = Array.prototype.slice.call(listEl.querySelectorAll('['+attr+']'));
        var node = items.find(x=>x.getAttribute(attr)===dragId);
        var ref  = items.find(x=>x.getAttribute(attr)===tid);
        if(!node || !ref) return;
        listEl.insertBefore(node, ref);
      });
      function sync(){
        var ids = Array.prototype.slice.call(listEl.querySelectorAll('['+attr+']')).map(x=>x.getAttribute(attr));
        hidden.value = JSON.stringify(ids);
      }
      sync();
      var form = listEl.closest('form');
      if(form) form.addEventListener('submit', sync);
    }
    makeDnD(document.getElementById('partnersList'), 'data-partner', document.getElementById('partnersOrder'));
    makeDnD(document.getElementById('reviewsList'), 'data-review', document.getElementById('reviewsOrder'));
  })();
  </script>

  <div style="height:14px"></div>
<div style="height:14px"></div>
  <h3 style="margin:0 0 8px">Footer</h3>
  <div class="row">
    <div><input name="f1" placeholder="Line 1" value="<?= h($blocks['footer']['line1'] ?? '') ?>"></div>
    <div><input name="f2" placeholder="Line 2" value="<?= h($blocks['footer']['line2'] ?? '') ?>"></div>
  </div>

  <div style="height:14px"></div>
  <button class="btn" type="submit">Save</button>
  <?php if($ok): ?><span class="muted" style="margin-left:10px"><?= h($ok) ?></span><?php endif; ?>
</form>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
