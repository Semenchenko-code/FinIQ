<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';
$ok=''; $err='';

function save_upload(string $field, string $prefix): ?string {
  if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
  $tmp = $_FILES[$field]['tmp_name'];
  $name = basename($_FILES[$field]['name']);
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if (!in_array($ext, ['png','jpg','jpeg','webp'], true)) return null;
  $fn = $prefix . '_' . date('Ymd_His') . '.' . $ext;
  $dest = __DIR__ . '/../uploads/' . $fn;
  if (!move_uploaded_file($tmp, $dest)) return null;
  return '/uploads/' . $fn;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $type = $_POST['type'] ?? '';
  if($type==='og'){
    $p = save_upload('file', 'og_'.$lang);
    if($p){
      $seoKey = 'seo_'.$lang;
      $seo = setting_get($seoKey, []);
      $seo['og_image'] = $p;
      setting_set($seoKey, $seo);
      audit('MEDIA_UPLOAD', ['type'=>'og','lang'=>$lang,'path'=>$p]);
      $ok='OG image updated ✅';
    } else $err='Upload failed (png/jpg/webp)';
  }

  if($type==='partner'){
    $idx = (int)($_POST['idx'] ?? 0);
    $p = save_upload('file', 'partner_'.$idx.'_'.$lang);
    if($p){
      $blocks = setting_get('blocks_'.$lang, []);
      if(isset($blocks['partners'][$idx])){
        $blocks['partners'][$idx]['logo'] = $p;
        setting_set('blocks_'.$lang, $blocks);
        audit('MEDIA_UPLOAD', ['type'=>'partner','lang'=>$lang,'idx'=>$idx,'path'=>$p]);
        $ok='Partner logo updated ✅';
      } else $err='Bad index';
    } else $err='Upload failed (png/jpg/webp)';
  }

  if($type==='avatar'){
    $idx = (int)($_POST['idx'] ?? 0);
    $p = save_upload('file', 'avatar_'.$idx.'_'.$lang);
    if($p){
      $blocks = setting_get('blocks_'.$lang, []);
      if(isset($blocks['reviews'][$idx])){
        $blocks['reviews'][$idx]['avatar'] = $p;
        setting_set('blocks_'.$lang, $blocks);
        audit('MEDIA_UPLOAD', ['type'=>'avatar','lang'=>$lang,'idx'=>$idx,'path'=>$p]);
        $ok='Avatar updated ✅';
      } else $err='Bad index';
    } else $err='Upload failed (png/jpg/webp)';
  }
}

$seo = setting_get('seo_'.$lang, ['og_image'=>'/assets/og-cover.png']);
$blocks = setting_get('blocks_'.$lang, []);

?><div class="card">
  <h2 style="margin:0 0 6px">Media (<?= h(strtoupper($lang)) ?>)</h2>
  <div class="muted">Завантаження OG / партнерів / аватарів. Файли: /uploads/</div>
  <?php if($ok): ?><div class="muted" style="margin-top:8px"><?= h($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div style="margin-top:8px;color:#ffb1b1"><?= h($err) ?></div><?php endif; ?>
</div>

<div class="card">
  <div style="display:flex;gap:10px">
    <a class="pill" href="/admin/media.php?lang=uk">UA</a>
    <a class="pill" href="/admin/media.php?lang=en">EN</a>
    <a class="pill" href="/admin/content.php?lang=<?= h($lang) ?>">Content</a>
  </div>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">OG image</h3>
  <div class="muted">Current: <a href="<?= h($seo['og_image'] ?? '/assets/og-cover.png') ?>" target="_blank">view</a></div>
  <form method="post" enctype="multipart/form-data" style="margin-top:10px">
    <input type="hidden" name="type" value="og">
    <input type="file" name="file" required>
    <div style="height:10px"></div>
    <button class="btn" type="submit">Upload</button>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Partners</h3>
  <table>
    <tr><th>#</th><th>Name</th><th>Logo</th><th>Upload</th></tr>
    <?php foreach(($blocks['partners'] ?? []) as $i=>$p): ?>
      <tr>
        <td><?= (int)$i ?></td>
        <td><?= h($p['name'] ?? '') ?></td>
        <td><?php if(!empty($p['logo'])): ?><a href="<?= h($p['logo']) ?>" target="_blank">view</a><?php else: ?><span class="muted">—</span><?php endif; ?></td>
        <td>
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="type" value="partner">
            <input type="hidden" name="idx" value="<?= (int)$i ?>">
            <input type="file" name="file" required>
            <button class="btn" type="submit">Upload</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Review avatars</h3>
  <table>
    <tr><th>#</th><th>Name</th><th>Avatar</th><th>Upload</th></tr>
    <?php foreach(($blocks['reviews'] ?? []) as $i=>$r): ?>
      <tr>
        <td><?= (int)$i ?></td>
        <td><?= h($r['name'] ?? '') ?></td>
        <td><?php if(!empty($r['avatar'])): ?><a href="<?= h($r['avatar']) ?>" target="_blank">view</a><?php else: ?><span class="muted">—</span><?php endif; ?></td>
        <td>
          <form method="post" enctype="multipart/form-data">
            <input type="hidden" name="type" value="avatar">
            <input type="hidden" name="idx" value="<?= (int)$i ?>">
            <input type="file" name="file" required>
            <button class="btn" type="submit">Upload</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
