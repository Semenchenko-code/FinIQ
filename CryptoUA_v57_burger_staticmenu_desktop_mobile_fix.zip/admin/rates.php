<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$pdo = db();

$ok = '';
$err = '';

$quote = setting_get('quote', ['quoteTtlSec'=>300]);
if (!is_array($quote)) $quote = ['quoteTtlSec'=>300];

if($_SERVER['REQUEST_METHOD']==='POST'){
  $action = $_POST['action'] ?? '';
  try{
    if($action === 'save_quote'){
      $quote['quoteTtlSec'] = max(30, (int)($_POST['quoteTtlSec'] ?? 300));
      setting_set('quote', $quote);
      audit('QUOTE_TTL_UPDATE', ['quote'=>$quote]);
      setting_set('calc_preview_ver', time()); // also bust preview cache
      $ok = 'Збережено ✅';
    }

    if($action === 'update_dir'){
      $id = (int)($_POST['id'] ?? 0);
      if($id<=0) throw new Exception('Bad id');

      $rate = (float)($_POST['rate'] ?? 0);
      $fee  = (float)($_POST['fee_pct'] ?? 0);
      $min  = ($_POST['min_amount'] ?? '') === '' ? null : (float)$_POST['min_amount'];
      $max  = ($_POST['max_amount'] ?? '') === '' ? null : (float)$_POST['max_amount'];

      $pdo->prepare("UPDATE directions SET rate=?, fee_pct=?, min_amount=?, max_amount=?, updated_at=? WHERE id=?")
          ->execute([$rate,$fee,$min,$max,now_iso(),$id]);

      audit('DIRECTION_RATES_UPDATE', ['id'=>$id,'rate'=>$rate,'fee'=>$fee,'min'=>$min,'max'=>$max]);
      setting_set('calc_preview_ver', time());
      $ok = 'Збережено ✅';
    }
  }catch(Throwable $e){
    $err = $e->getMessage();
  }
}

$dirs = directions_list(false);
$prevVer = (int)setting_get('calc_preview_ver', 0);
if($prevVer<=0) $prevVer = time();
?>
<div class="card">
  <h2 style="margin:0 0 6px">Rates & Fees</h2>
  <div class="muted">Тут налаштовуються <b>курс</b>, <b>комісія</b> та <b>мін/макс</b> для кожного напряму. Список напрямів (пари) — у <a href="/admin/directions.php">Directions</a>.</div>
  <?php if($ok): ?><div style="margin-top:10px" class="muted"><?= h($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div style="margin-top:10px;color:#ffb4b4"><?= h($err) ?></div><?php endif; ?>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Фіксація курсу</h3>
  <form method="post">
    <input type="hidden" name="action" value="save_quote">
    <div class="row" style="grid-template-columns:220px 1fr;align-items:end">
      <div>
        <label class="muted">Quote TTL (сек)</label>
        <input name="quoteTtlSec" type="number" step="1" value="<?= h($quote['quoteTtlSec'] ?? 300) ?>">
      </div>
      <div class="muted">Скільки секунд тримати фіксований курс для створеної заявки.</div>
    </div>
    <div style="margin-top:10px">
      <button class="btn" type="submit">Save</button>
    </div>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Напрями: курс / комісія / ліміти</h3>

  <table class="table">
    <thead>
      <tr>
        <th>Pair</th>
        <th>Enabled</th>
        <th>Rate (to за 1 from)</th>
        <th>Fee %</th>
        <th>Min</th>
        <th>Max</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($dirs as $d): ?>
        <tr>
          <td><b><?= h($d['from_asset']) ?></b> → <b><?= h($d['to_asset']) ?></b></td>
          <td><?= ((int)$d['enabled']===1) ? '<span class="pill">ON</span>' : '<span class="pill" style="opacity:.5">OFF</span>' ?></td>
          <td style="min-width:190px">
            <form method="post" style="display:flex;gap:10px;align-items:center">
              <input type="hidden" name="action" value="update_dir">
              <input type="hidden" name="id" value="<?= (int)$d['id'] ?>">
              <input name="rate" type="number" step="0.0000001" value="<?= h($d['rate']) ?>" style="width:180px">
          </td>
          <td><input name="fee_pct" type="number" step="0.01" value="<?= h($d['fee_pct']) ?>" style="width:90px"></td>
          <td><input name="min_amount" type="number" step="0.0000001" value="<?= h($d['min_amount']) ?>" style="width:110px" placeholder="—"></td>
          <td><input name="max_amount" type="number" step="0.0000001" value="<?= h($d['max_amount']) ?>" style="width:110px" placeholder="—"></td>
          <td style="white-space:nowrap">
              <button class="btn" type="submit">Save</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Preview (saved)</h3>
  <div class="muted" style="margin-bottom:10px">Онови сторінку після Save (або reload iframe) — побачиш калькулятор з актуальними напрямами.</div>
  <iframe src="/preview/calculator.php?lang=uk&v=<?= (int)$prevVer ?>" style="width:100%;height:520px;border:1px solid rgba(255,255,255,.12);border-radius:16px;background:#0b1026"></iframe>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
