<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$pdo=db();
$ok=''; $err='';

if($_SERVER['REQUEST_METHOD']==='POST'){
  $action = $_POST['action'] ?? '';
  if($action==='create'){
    $username = trim($_POST['username'] ?? '');
    $role = ($_POST['role'] ?? 'operator') === 'admin' ? 'admin' : 'operator';
    $pass = (string)($_POST['password'] ?? '');
    if(!$username || !$pass){ $err='Fill username/password'; }
    else{
      $hash = password_hash($pass, PASSWORD_DEFAULT);
      try{
        $pdo->prepare("INSERT INTO users(username, role, pass_hash, created_at) VALUES(?,?,?,?)")
            ->execute([$username,$role,$hash,now_iso()]);
        audit('USER_CREATE', ['username'=>$username,'role'=>$role]);
        $ok='Created ✅';
      } catch(Throwable $e){ $err='User exists?'; }
    }
  }
  if($action==='pass'){
    $id = (int)($_POST['id'] ?? 0);
    $pass = (string)($_POST['password'] ?? '');
    if($id>0 && $pass){
      $hash = password_hash($pass, PASSWORD_DEFAULT);
      $pdo->prepare("UPDATE users SET pass_hash=? WHERE id=?")->execute([$hash,$id]);
      audit('USER_PASS', ['id'=>$id]);
      $ok='Password updated ✅';
    }
  }
  if($action==='del'){
    $id=(int)($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
    audit('USER_DELETE', ['id'=>$id]);
    $ok='Deleted ✅';
  }
}

$list = $pdo->query("SELECT id,username,role,created_at FROM users ORDER BY id ASC")->fetchAll();

?><div class="card">
  <h2 style="margin:0 0 6px">Users</h2>
  <div class="muted">Ролі: admin / operator</div>
  <?php if($ok): ?><div class="muted" style="margin-top:8px"><?= h($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div style="margin-top:8px;color:#ffb1b1"><?= h($err) ?></div><?php endif; ?>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Create</h3>
  <form method="post">
    <input type="hidden" name="action" value="create">
    <div class="row">
      <div><label class="muted">Username</label><input name="username"></div>
      <div><label class="muted">Role</label>
        <select name="role"><option value="operator">operator</option><option value="admin">admin</option></select>
      </div>
    </div>
    <div style="height:10px"></div>
    <label class="muted">Password</label>
    <input name="password" type="password">
    <div style="height:10px"></div>
    <button class="btn" type="submit">Create</button>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">All users</h3>
  <table>
    <tr><th>ID</th><th>Username</th><th>Role</th><th>Created</th><th>Actions</th></tr>
    <?php foreach($list as $u): ?>
      <tr>
        <td>#<?= (int)$u['id'] ?></td>
        <td><?= h($u['username']) ?></td>
        <td><span class="tag"><?= h($u['role']) ?></span></td>
        <td class="muted"><?= h($u['created_at']) ?></td>
        <td style="display:flex;gap:8px;flex-wrap:wrap">
          <form method="post" style="display:flex;gap:8px;align-items:center">
            <input type="hidden" name="action" value="pass">
            <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
            <input name="password" type="password" placeholder="new password">
            <button class="btn2" type="submit">Set</button>
          </form>
          <form method="post" onsubmit="return confirm('Delete user?')">
            <input type="hidden" name="action" value="del">
            <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
            <button class="btn2" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
