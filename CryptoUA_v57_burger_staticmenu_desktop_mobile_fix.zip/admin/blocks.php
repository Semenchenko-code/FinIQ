<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

function norm_arr($v): array {
  if(is_string($v)){ $j=json_decode($v,true); $v=$j; }
  return is_array($v)?$v:[];
}
function save_blocks(array $blocks){
  setting_set('custom_blocks', array_values($blocks));
  setting_set('visual_ver', time());
}

$blocks = norm_arr(setting_get('custom_blocks', []));
$msg = $err = '';

$action = $_GET['a'] ?? '';
$id = (string)($_GET['id'] ?? '');

function find_block(&$blocks, $id){
  foreach($blocks as $i=>$b){
    if(is_array($b) && (string)($b['id']??'')===$id) return $i;
  }
  return -1;
}

function handle_upload(string $field): string {
  if(empty($_FILES[$field]) || $_FILES[$field]['error']!==UPLOAD_ERR_OK) return '';
  $tmp = $_FILES[$field]['tmp_name'];
  $name = basename($_FILES[$field]['name']);
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if(!in_array($ext, ['png','jpg','jpeg','webp','svg'], true)) return '';
  $dir = base_path('uploads/custom');
  if(!is_dir($dir)) @mkdir($dir, 0775, true);
  $safe = preg_replace('~[^a-zA-Z0-9._-]+~','_', pathinfo($name, PATHINFO_FILENAME));
  $fn = $safe . '_' . time() . '.' . $ext;
  $dest = $dir . '/' . $fn;
  if(!@move_uploaded_file($tmp, $dest)) return '';
  return '/uploads/custom/' . $fn;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
  $type = (string)($_POST['type'] ?? 'text');
  if(!in_array($type, ['text','image','cta'], true)) $type='text';
  $preset = (string)($_POST['preset'] ?? '');
  if(!in_array($preset, ['','glass','gradient','split'], true)) $preset='';

  $editId = (string)($_POST['id'] ?? '');
  if($editId===''){
    $editId = substr(bin2hex(random_bytes(6)),0,10);
  }

  $data = [
    'id' => $editId,
    'type' => $type,
    'preset' => $preset,
    'title_uk' => trim((string)($_POST['title_uk'] ?? '')),
    'title_en' => trim((string)($_POST['title_en'] ?? '')),
    'text_uk'  => trim((string)($_POST['text_uk'] ?? '')),
    'text_en'  => trim((string)($_POST['text_en'] ?? '')),
    'btn_uk'   => trim((string)($_POST['btn_uk'] ?? '')),
    'btn_en'   => trim((string)($_POST['btn_en'] ?? '')),
    'url'      => trim((string)($_POST['url'] ?? '#rates')),
    'img'      => trim((string)($_POST['img_old'] ?? '')),
  ];

  $up = handle_upload('img');
  if($up) $data['img'] = $up;

  $idx = find_block($blocks, $editId);
  if($idx>=0) $blocks[$idx] = $data;
  else $blocks[] = $data;

  save_blocks($blocks);
  audit('CUSTOM_BLOCK_SAVE', ['id'=>$editId,'type'=>$type]);
  $msg = 'Saved';
}

if($action==='del' && $id!==''){
  $idx = find_block($blocks, $id);
  if($idx>=0){
    unset($blocks[$idx]);
    save_blocks($blocks);
    audit('CUSTOM_BLOCK_DEL', ['id'=>$id]);
    $msg='Deleted';
  }
}

$edit = null;
if($action==='edit' && $id!==''){
  $idx = find_block($blocks, $id);
  if($idx>=0) $edit = $blocks[$idx];
}
?>
<div class="container">
  <h2 style="margin:0 0 10px">Custom blocks</h2>
  <div class="muted" style="margin-bottom:14px">Створи блоки типу Текст / Картинка / CTA. Потім їх можна перетягувати та стилізувати у Home Builder.</div>
  <?php if($msg): ?><div class="ok" style="margin-bottom:12px"><?= h($msg) ?></div><?php endif; ?>

  <div style="display:grid;grid-template-columns:420px 1fr;gap:16px;align-items:start">
    <div class="card" style="padding:14px">
      <h3 style="margin:0 0 10px"><?= $edit ? 'Edit block' : 'Add block' ?></h3>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= h($edit['id'] ?? '') ?>" />
        <input type="hidden" name="img_old" value="<?= h($edit['img'] ?? '') ?>" />

        <label class="field">
          <span>Type</span>
          <select name="type">
            <?php $t = (string)($edit['type'] ?? 'text'); ?>
            <option value="text" <?= $t==='text'?'selected':'' ?>>Text</option>
            <option value="image" <?= $t==='image'?'selected':'' ?>>Image</option>
            <option value="cta" <?= $t==='cta'?'selected':'' ?>>CTA</option>
          </select>
        </label>

        <div class="grid" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
          <label class="field"><span>Title UK</span><input name="title_uk" value="<?= h($edit['title_uk'] ?? '') ?>" /></label>
          <label class="field"><span>Title EN</span><input name="title_en" value="<?= h($edit['title_en'] ?? '') ?>" /></label>
        </div>

        <div class="grid" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
          <label class="field"><span>Text UK</span><textarea name="text_uk" rows="4"><?= h($edit['text_uk'] ?? '') ?></textarea></label>
          <label class="field"><span>Text EN</span><textarea name="text_en" rows="4"><?= h($edit['text_en'] ?? '') ?></textarea></label>
        </div>

        <div class="grid" style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
          <label class="field"><span>Button UK</span><input name="btn_uk" value="<?= h($edit['btn_uk'] ?? '') ?>" /></label>
          <label class="field"><span>Button EN</span><input name="btn_en" value="<?= h($edit['btn_en'] ?? '') ?>" /></label>
        </div>

        <label class="field" style="margin-top:10px">
          <span>Button URL</span>
          <input name="url" value="<?= h($edit['url'] ?? '#rates') ?>" />
        </label>

        <label class="field" style="margin-top:10px">
          <span>Image (for Image/CTA)</span>
          <input type="file" name="img" accept=".png,.jpg,.jpeg,.webp,.svg" />
        </label>
        <?php if(!empty($edit['img'])): ?>
          <div class="muted" style="margin-top:8px">Current: <a href="<?= h($edit['img']) ?>" target="_blank"><?= h($edit['img']) ?></a></div>
        <?php endif; ?>

        <div style="display:flex;gap:8px;margin-top:12px">
          <button type="submit" class="btn">Save</button>
          <?php if($edit): ?><a class="btn btn--ghost" href="/admin/blocks.php">Cancel</a><?php endif; ?>
        </div>
      </form>
    </div>

    <div class="card" style="padding:14px">
      <h3 style="margin:0 0 10px">Existing blocks</h3>
      <?php if(!count($blocks)): ?>
        <div class="muted">No blocks yet.</div>
      <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:10px">
        <?php foreach($blocks as $b): if(!is_array($b)) continue; $bid=(string)($b['id']??''); ?>
          <div style="padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:14px;background:rgba(255,255,255,.03)">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
              <div>
                <strong><?= h(($b['title_uk'] ?? '') ?: 'Block') ?></strong>
                <div class="muted" style="font-size:12px"><?= h('cb_'.$bid) ?> • <?= h($b['type'] ?? '') ?></div>
              </div>
              <div style="display:flex;gap:8px">
                <a class="btn btn--ghost" href="/admin/blocks.php?a=edit&id=<?= h($bid) ?>">Edit</a>
                <a class="btn btn--ghost" href="/admin/blocks.php?a=del&id=<?= h($bid) ?>" onclick="return confirm('Delete?')">Delete</a>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
