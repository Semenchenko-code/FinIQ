<?php
require_once __DIR__ . '/../helpers.php';
$u = require_role('admin');
include __DIR__ . '/_layout.php';

function save_upload(string $field, string $prefix): ?string {
  if (!isset($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
  $tmp = $_FILES[$field]['tmp_name'] ?? '';
  if(!$tmp) return null;

  $name = basename((string)($_FILES[$field]['name'] ?? 'file'));
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if(!in_array($ext, ['png','jpg','jpeg','webp','svg'], true)) return null;

  $dir = __DIR__ . '/../uploads/';
  if(!is_dir($dir)) { @mkdir($dir, 0755, true); }

  $fn = $prefix . '_' . date('Ymd_His') . '.' . $ext;
  $dest = $dir . $fn;
  if(!move_uploaded_file($tmp, $dest)) return null;
  return '/uploads/' . $fn;
}

$logo = (string)setting_get('brand_logo', '/assets/logo.svg');
$burger = (string)setting_get('brand_burger_icon', '');
$ver = (int)setting_get('brand_assets_ver', 0);

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $newLogo = save_upload('logo_file', 'brand_logo');
  $newBurger = save_upload('burger_file', 'brand_burger');

  if($newLogo){ $logo = $newLogo; setting_set('brand_logo', $logo); audit('BRAND_LOGO_SET', ['path'=>$logo]); }
  if($newBurger){ $burger = $newBurger; setting_set('brand_burger_icon', $burger); audit('BRAND_BURGER_SET', ['path'=>$burger]); }

  if($newLogo || $newBurger){
    $ver = time();
    setting_set('brand_assets_ver', $ver);
    $msg = 'Saved. Cache-bust updated.';
  } else {
    $msg = 'No files uploaded.';
  }
}

function with_ver(string $url, int $ver): string {
  if($ver<=0 || !$url) return $url;
  $sep = (strpos($url,'?')===false) ? '?' : '&';
  return $url . $sep . 'v=' . $ver;
}

$logoV = with_ver($logo, $ver);
$burgerV = with_ver($burger, $ver);
?>
<h1>Branding</h1>
<?php if($msg): ?><div class="card"><?= h($msg) ?></div><?php endif; ?>

<div class="card">
  <form method="post" enctype="multipart/form-data">
    <div class="row">
      <div>
        <label>Site logo (svg/png/webp/jpg)</label>
        <input type="file" name="logo_file" accept=".svg,.png,.jpg,.jpeg,.webp" />
        <div style="margin-top:10px;display:flex;align-items:center;gap:10px">
          <div style="opacity:.8">Current:</div>
          <img id="logoPreview" src="<?= h($logoV) ?>" alt="logo" style="height:34px;max-width:220px;object-fit:contain" />
        </div>
      </div>
      <div>
        <label>Burger icon (svg/png/webp/jpg)</label>
        <input type="file" name="burger_file" accept=".svg,.png,.jpg,.jpeg,.webp" />
        <div style="margin-top:10px;display:flex;align-items:center;gap:10px">
          <div style="opacity:.8">Current:</div>
          <button type="button" class="pill" style="display:flex;align-items:center;gap:10px">
            <?php if($burgerV): ?>
              <img id="burgerPreview" src="<?= h($burgerV) ?>" alt="burger" style="height:20px;width:20px;object-fit:contain" />
            <?php else: ?>
              <span id="burgerPreview" style="display:inline-block;width:20px;height:14px;border-top:2px solid rgba(255,255,255,.9);border-bottom:2px solid rgba(255,255,255,.9);position:relative"></span>
              <span style="position:absolute;width:18px;height:2px;background:rgba(255,255,255,.9);transform:translateY(-1px)"></span>
            <?php endif; ?>
            <span style="opacity:.85">Menu</span>
          </button>
        </div>
      </div>
    </div>

    <div style="margin-top:12px">
      <button class="btn" type="submit">Save</button>
    </div>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Preview (saved settings)</h3>
  <div style="opacity:.85;margin:0 0 10px">Після Save онови iframe (reload) — побачиш як виглядатиме шапка.</div>
  <iframe src="/preview/header.php" style="width:100%;height:140px;border:1px solid rgba(255,255,255,.12);border-radius:14px;background:#0b1026"></iframe>
</div>

<script>
  // instant preview before save
  function bindPreview(inputName, imgId){
    const inp = document.querySelector('input[name="'+inputName+'"]');
    const img = document.getElementById(imgId);
    if(!inp || !img) return;
    inp.addEventListener('change', ()=>{
      const f = inp.files && inp.files[0];
      if(!f) return;
      const url = URL.createObjectURL(f);
      if(img.tagName === 'IMG'){
        img.src = url;
      }else{
        // replace placeholder span with img
        const im = document.createElement('img');
        im.id = imgId;
        im.src = url;
        im.alt = 'burger';
        im.style.height='20px';
        im.style.width='20px';
        im.style.objectFit='contain';
        img.parentNode.replaceChild(im, img);
      }
    });
  }
  bindPreview('logo_file','logoPreview');
  bindPreview('burger_file','burgerPreview');
</script>
<?php include __DIR__ . '/_footer.php'; ?>
