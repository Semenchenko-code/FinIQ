<?php
require_once __DIR__ . '/../helpers.php';
if (!is_installed()) { header('Location: /install.php'); exit; }
session_start();
if (isset($_SESSION['user'])) { header('Location: /admin/dashboard.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $u = trim($_POST['username'] ?? '');
  $p = (string)($_POST['password'] ?? '');
  try { $pdo = db(); } catch(Throwable $e) { $error = 'DB помилка: ' . $e->getMessage() . ' (Перейди на /install.php?force=1 і обери MySQL)'; $pdo=null; }
  if($pdo){
  $st = $pdo->prepare("SELECT id,username,role,pass_hash FROM users WHERE username=? LIMIT 1");
  $st->execute([$u]);
  $row = $st->fetch();
  if ($row && password_verify($p, $row['pass_hash'])) {
    $_SESSION['user'] = ['id'=>$row['id'],'username'=>$row['username'],'role'=>$row['role']];
    audit('LOGIN', ['user'=>$row['username']]);
    header('Location: /admin/dashboard.php');
    exit;
  }
    $error = 'Невірний логін або пароль';
  }

}
?><!doctype html>
<html lang="uk"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login</title>
<style>
body{font-family:system-ui;background:#070a18;color:#e8ecff;display:flex;justify-content:center;align-items:center;min-height:100vh;margin:0}
.card{width:min(420px,92%);border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.03);border-radius:18px;padding:18px}
input{width:100%;padding:10px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.04);color:#e8ecff}
.btn{margin-top:12px;width:100%;padding:10px 14px;border-radius:14px;border:none;cursor:pointer;background:linear-gradient(135deg, rgba(124,92,255,.95), rgba(35,213,171,.95));color:#071022;font-weight:800}
.muted{color:#a9b2d6}
.err{color:#ffb1b1;margin-top:8px}
</style>
</head><body>
<div class="card">
  <h2 style="margin:0 0 8px">CryptoUA Admin</h2>
  <p class="muted" style="margin:0 0 12px">Вхід в адмін-панель</p>
  <form method="post">
    <label class="muted">Username</label>
    <input name="username" required>
    <div style="height:10px"></div>
    <label class="muted">Password</label>
    <input name="password" type="password" required>
    <button class="btn" type="submit">Увійти</button>
    <?php if($error): ?><div class="err"><?= h($error) ?></div><?php endif; ?>
  </form>
</div>
</body></html>
