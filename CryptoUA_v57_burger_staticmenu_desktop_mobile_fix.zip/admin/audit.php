<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$pdo=db();
$rows = $pdo->query("SELECT * FROM audit_log ORDER BY id DESC LIMIT 500")->fetchAll();

?><div class="card">
  <h2 style="margin:0 0 6px">Audit log</h2>
  <div class="muted">Останні 500 подій</div>
</div>

<div class="card">
  <table>
    <tr><th>ID</th><th>Time</th><th>User</th><th>Role</th><th>IP</th><th>Action</th><th>Meta</th></tr>
    <?php foreach($rows as $r): ?>
      <tr>
        <td>#<?= (int)$r['id'] ?></td>
        <td class="muted"><?= h($r['ts']) ?></td>
        <td><?= h($r['username']) ?></td>
        <td class="muted"><?= h($r['role']) ?></td>
        <td class="muted"><?= h($r['ip']) ?></td>
        <td><span class="tag"><?= h($r['action']) ?></span></td>
        <td class="muted" style="max-width:320px;white-space:pre-wrap"><?= h($r['meta_json']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
