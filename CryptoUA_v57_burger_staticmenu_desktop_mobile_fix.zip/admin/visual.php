<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

function save_upload(string $field, string $prefix): ?string {
  if (!isset($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
  $tmp = $_FILES[$field]['tmp_name'] ?? '';
  if(!$tmp) return null;

  $name = basename((string)($_FILES[$field]['name'] ?? 'file'));
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if(!in_array($ext, ['png','jpg','jpeg','webp','svg'], true)) return null;

  $dir = __DIR__ . '/../uploads/';
  if(!is_dir($dir)) { @mkdir($dir, 0755, true); }

  $fn = $prefix . '_' . date('Ymd_His') . '.' . $ext;
  $dest = $dir . $fn;
  if(!move_uploaded_file($tmp, $dest)) return null;
  return '/uploads/' . $fn;
}

$ver = (int)setting_get('visual_ver', 0);
if($ver<=0) $ver = time();

$logo = (string)setting_get('brand_logo', '/assets/logo.svg');

$burger_desktop = (string)setting_get('burger_icon_desktop', (string)setting_get('burger_icon', ''));
$burger_mobile  = (string)setting_get('burger_icon_mobile', '');
if($burger_mobile==='') $burger_mobile = $burger_desktop;

$burger_ver = (int)setting_get('burger_icon_ver', 0);
if($burger_ver<=0) $burger_ver = $ver;


$reviews = setting_get('reviews_media', ['r1'=>'', 'r2'=>'', 'r3'=>'']);
if(!is_array($reviews)) $reviews = ['r1'=>'','r2'=>'','r3'=>''];

$theme = setting_get('theme', []);
if(!is_array($theme)) $theme = [];
$themeDefaults = [
  'bg1' => 'rgba(124,92,255,.18)',
  'bg2' => 'rgba(35,213,171,.14)',
  'bg3' => 'rgba(124,92,255,.10)',
  'btn1'=> 'rgba(124,92,255,.95)',
  'btn2'=> 'rgba(35,213,171,.95)',
  'cta1'=> '#22d3a9',
  'cta2'=> '#2cff8a',
  'ctaGlow'=> 'rgba(34,211,169,.55)',
];
$theme = array_merge($themeDefaults, $theme);

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $changed = false;

  // Actions
  $action = (string)($_POST['action'] ?? '');

  if($action==='undo_theme'){
    $prev = setting_get('theme_prev', null);
    if(is_array($prev)){
      $cur = setting_get('theme', []);
      setting_set('theme', $prev);
      setting_set('theme_prev', $cur);
      $theme = array_merge($themeDefaults, $prev);
      $changed = true;
      audit('THEME_UNDO',[]);
    }
  }

  if($action==='save_swatch'){
    $name = trim((string)($_POST['swatch_name'] ?? 'Palette'));
    $curTheme = setting_get('theme', []);
    if(!is_array($curTheme)) $curTheme = $theme;
    $curMode = (string)setting_get('theme_mode','night');
    if($curMode!=='day') $curMode='night';
    $sw = ['id'=>bin2hex(random_bytes(4)),'name'=>$name,'mode'=>$curMode,'theme'=>$curTheme,'ts'=>time()];
    $swatches = setting_get('theme_swatches', []);
    if(!is_array($swatches)) $swatches=[];
    array_unshift($swatches, $sw);
    $swatches = array_slice($swatches, 0, 12);
    setting_set('theme_swatches', $swatches);
    audit('THEME_SWATCH_SAVE',['id'=>$sw['id'],'name'=>$name]);
    $msg = 'Swatch saved ✅';
  }

  if($action==='apply_swatch'){
    $id = (string)($_POST['swatch_id'] ?? '');
    $swatches = setting_get('theme_swatches', []);
    if(!is_array($swatches)) $swatches=[];
    foreach($swatches as $sw){
      if(($sw['id'] ?? '') === $id && is_array($sw['theme'] ?? null)){
        // store prev
        setting_set('theme_prev', setting_get('theme', []));
        setting_set('theme', $sw['theme']);
        $theme = array_merge($themeDefaults, $sw['theme']);
        $tm = (($sw['mode'] ?? 'night')==='day') ? 'day' : 'night';
        setting_set('theme_mode', $tm);
        $theme_mode = $tm;
        $changed = true;
        audit('THEME_SWATCH_APPLY',['id'=>$id]);
        break;
      }
    }
  }

  if($action==='delete_swatch'){
    $id = (string)($_POST['swatch_id'] ?? '');
    $swatches = setting_get('theme_swatches', []);
    if(!is_array($swatches)) $swatches=[];
    $swatches = array_values(array_filter($swatches, fn($s)=>($s['id']??'')!==$id));
    setting_set('theme_swatches', $swatches);
    audit('THEME_SWATCH_DELETE',['id'=>$id]);
    $msg = 'Swatch deleted ✅';
  }

  // Presets
  $preset = (string)($_POST['preset'] ?? '');
  if($preset==='premium_night' || $preset==='premium_day'){
    if($preset==='premium_night'){
      $theme = array_merge($theme, [
        'bg1'=>'rgba(124,92,255,.22)',
        'bg2'=>'rgba(35,213,171,.18)',
        'bg3'=>'rgba(124,92,255,.12)',
        'btn1'=>'rgba(124,92,255,.98)',
        'btn2'=>'rgba(35,213,171,.98)',
        'cta1'=>'#22d3a9',
        'cta2'=>'#2cff8a',
        'ctaGlow'=>'rgba(34,211,169,.60)'
      ]);
    } else {
      $theme = array_merge($theme, [
        'bg1'=>'rgba(86,110,255,.14)',
        'bg2'=>'rgba(35,213,171,.10)',
        'bg3'=>'rgba(86,110,255,.08)',
        'btn1'=>'rgba(86,110,255,.96)',
        'btn2'=>'rgba(35,213,171,.92)',
        'cta1'=>'#16c79a',
        'cta2'=>'#2cff8a',
        'ctaGlow'=>'rgba(22,199,154,.45)'
      ]);
      // also switch to day mode
      $theme_mode = 'day';
    }
    $changed = true;
    audit('THEME_PRESET_APPLY',['preset'=>$preset]);
  }

  // CTA presets (only CTA button colors)
  $ctaPreset = (string)($_POST['cta_preset'] ?? '');
  if($ctaPreset){
    setting_set('theme_prev', setting_get('theme', []));
    if($ctaPreset==='cta_green'){
      $theme['cta1']='#22d3a9'; $theme['cta2']='#2cff8a'; $theme['ctaGlow']='rgba(34,211,169,.60)';
    }elseif($ctaPreset==='cta_purple'){
      $theme['cta1']='#7c5cff'; $theme['cta2']='#23d5ab'; $theme['ctaGlow']='rgba(124,92,255,.45)';
    }elseif($ctaPreset==='cta_orange'){
      $theme['cta1']='#ffb020'; $theme['cta2']='#ff4fd8'; $theme['ctaGlow']='rgba(255,176,32,.45)';
    }
    $changed = true;
    audit('CTA_PRESET_APPLY',['preset'=>$ctaPreset]);
  }

  $p = save_upload('logo_file','brand_logo');
  if($p){ setting_set('brand_logo', $p); $logo = $p; $changed = true; audit('VISUAL_LOGO_SET',['path'=>$p]); }


  $p = save_upload('burger_desktop_file','burger_desktop');
  if($p){ setting_set('burger_icon_desktop', $p); $burger_desktop = $p; $changed = true; audit('VISUAL_BURGER_DESKTOP_SET',['path'=>$p]); }

  $p = save_upload('burger_mobile_file','burger_mobile');
  if($p){ setting_set('burger_icon_mobile', $p); $burger_mobile = $p; $changed = true; audit('VISUAL_BURGER_MOBILE_SET',['path'=>$p]); }


  foreach(['r1','r2','r3'] as $k){
    $p = save_upload('review_'.$k, 'review_'.$k);
    if($p){ $reviews[$k] = $p; $changed = true; audit('VISUAL_REVIEW_IMG_SET',['slot'=>$k,'path'=>$p]); }
  }
  setting_set('reviews_media', $reviews);

  // Theme (colors / gradients)
  $t = $theme;
  $fields = [
    'bg1' => 'theme_bg1',
    'bg2' => 'theme_bg2',
    'bg3' => 'theme_bg3',
    'btn1'=> 'theme_btn1',
    'btn2'=> 'theme_btn2',
    'cta1'=> 'theme_cta1',
    'cta2'=> 'theme_cta2',
    'ctaGlow'=> 'theme_ctaGlow',
  ];
  foreach($fields as $k=>$f){
    $val = trim((string)($_POST[$f] ?? ''));
    if($val !== '' && $val !== (string)$t[$k]){ $t[$k] = $val; $changed = true; }
  }
  $theme = $t;
  setting_set('theme', $theme);

  if($changed){
    $ver = time();
    setting_set('visual_ver', $ver);
    setting_set('brand_assets_ver', $ver);
    setting_set('burger_icon_ver', $ver);
    $msg = 'Saved ✅ (Reload preview below)';
  }else{
    $msg = 'No changes';
  }
}

function with_ver(string $url, int $ver): string {
  if($ver<=0 || !$url) return $url;
  $sep = (strpos($url,'?')===false) ? '?' : '&';
  return $url . $sep . 'v=' . $ver;
}
$logoV = with_ver($logo, $ver);
?>
<h1>Visual editor</h1>
<style>.sw{display:inline-block;width:14px;height:14px;border-radius:6px;border:1px solid rgba(255,255,255,.18)}</style>
<?php if($msg): ?><div class="card"><?= h($msg) ?></div><?php endif; ?>

<div class="card">
  <h3 style="margin:0 0 10px">Logo + Reviews images</h3>
  <form method="post" enctype="multipart/form-data">
    <label>Upload logo (svg/png/webp/jpg)</label>
    <input type="file" name="logo_file" accept=".svg,.png,.jpg,.jpeg,.webp" />
    <div style="margin-top:10px;display:flex;align-items:center;gap:10px">
      <div class="muted">Preview:</div>
      <img id="logoPreview" src="<?= h($logoV) ?>" alt="logo" style="height:34px;max-width:220px;object-fit:contain" />
    </div>
    <div style="margin-top:12px">
      
      <label>Burger icon — Desktop (png/svg/webp)</label>
      <input type="file" name="burger_desktop_file" accept=".svg,.png,.jpg,.jpeg,.webp" />
      <div style="margin-top:8px;display:flex;align-items:center;gap:10px">
        <div class="muted">Preview:</div>
        <?php if(!empty($burger_desktop)): ?>
          <img id="burgerPrevDesktop" src="<?= h(with_ver($burger_desktop, $burger_ver ?: $ver)) ?>" style="height:26px;width:26px;object-fit:contain" />
        <?php else: ?>
          <div id="burgerPrevDesktop" class="muted">—</div>
        <?php endif; ?>
      </div>

      <div style="height:10px"></div>

      <label>Burger icon — Mobile (png/svg/webp)</label>
      <input type="file" name="burger_mobile_file" accept=".svg,.png,.jpg,.jpeg,.webp" />
      <div style="margin-top:8px;display:flex;align-items:center;gap:10px">
        <div class="muted">Preview:</div>
        <?php if(!empty($burger_mobile)): ?>
          <img id="burgerPrevMobile" src="<?= h(with_ver($burger_mobile, $burger_ver ?: $ver)) ?>" style="height:26px;width:26px;object-fit:contain" />
        <?php else: ?>
          <div id="burgerPrevMobile" class="muted">—</div>
        <?php endif; ?>
      </div>


    <div style="height:14px"></div>

    <div class="card" style="margin-top:14px">
      <h3 style="margin:0 0 10px">Theme (background + buttons)</h3>
      <div class="muted" style="margin-bottom:10px">Зміни застосовуються до фону і градієнтів кнопок. Прев’ю оновлюється одразу (без Save).</div>

      <div class="row" style="grid-template-columns:1fr 1fr;align-items:end">
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn" type="submit" name="preset" value="premium_night">Apply Premium Night</button>
          <button class="btn" type="submit" name="preset" value="premium_day">Apply Premium Day</button>
        </div>
        <div class="muted">Одна кнопка: застосувати пресет і зберегти.</div>
      </div>

      <div style="height:12px"></div>
      <div class="muted" style="margin-bottom:8px">Color picker (замість ручного rgba/hex). Прозорість — повзунок Alpha.</div>


      <div class="row">
        <div>
          <label>Background glow #1</label>
          <input type="hidden" name="theme_bg1" id="theme_bg1" value="<?= h($theme['bg1']) ?>">
          <div class="row" style="grid-template-columns:120px 1fr;gap:10px;align-items:center">
            <input type="color" id="pick_bg1" value="#7c5cff">
            <input type="range" id="alpha_bg1" min="0" max="1" step="0.01" value="0.22">
          </div>" placeholder="rgba(124,92,255,.18)">
        </div>
        <div>
          <label>Background glow #2</label>
          <input type="hidden" name="theme_bg2" id="theme_bg2" value="<?= h($theme['bg2']) ?>">
          <div class="row" style="grid-template-columns:120px 1fr;gap:10px;align-items:center">
            <input type="color" id="pick_bg2" value="#23d5ab">
            <input type="range" id="alpha_bg2" min="0" max="1" step="0.01" value="0.18">
          </div>" placeholder="rgba(35,213,171,.14)">
        </div>
      </div>

      <div class="row" style="margin-top:10px">
        <div>
          <label>Background glow #3</label>
          <input type="hidden" name="theme_bg3" id="theme_bg3" value="<?= h($theme['bg3']) ?>">
          <div class="row" style="grid-template-columns:120px 1fr;gap:10px;align-items:center">
            <input type="color" id="pick_bg3" value="#7c5cff">
            <input type="range" id="alpha_bg3" min="0" max="1" step="0.01" value="0.12">
          </div>" placeholder="rgba(124,92,255,.10)">
        </div>
        <div>
          <label>Primary button gradient (btn1 → btn2)</label>
          <input type="hidden" name="theme_btn1" id="theme_btn1" value="<?= h($theme['btn1']) ?>">
          <input type="hidden" name="theme_btn2" id="theme_btn2" value="<?= h($theme['btn2']) ?>">
          <div class="row" style="grid-template-columns:120px 1fr 120px 1fr;gap:10px;align-items:center">
            <input type="color" id="pick_btn1" value="#7c5cff">
            <input type="range" id="alpha_btn1" min="0" max="1" step="0.01" value="0.98">
            <input type="color" id="pick_btn2" value="#23d5ab">
            <input type="range" id="alpha_btn2" min="0" max="1" step="0.01" value="0.98">
          </div>" placeholder="rgba(35,213,171,.95)">
          </div>
        </div>
      </div>

      <div class="row" style="margin-top:10px">
        <div>
          <label>CTA button gradient (cta1 → cta2)</label>
          <input type="hidden" name="theme_cta1" id="theme_cta1" value="<?= h($theme['cta1']) ?>">
          <input type="hidden" name="theme_cta2" id="theme_cta2" value="<?= h($theme['cta2']) ?>">
          <div class="row" style="grid-template-columns:120px 120px;gap:10px;align-items:center">
            <input type="color" id="pick_cta1" value="#22d3a9">
            <input type="color" id="pick_cta2" value="#2cff8a">
          </div>" placeholder="#2cff8a">
          </div>
        </div>
        <div>
          <label>CTA glow</label>
          <input type="hidden" name="theme_ctaGlow" id="theme_ctaGlow" value="<?= h($theme['ctaGlow']) ?>">
          <div class="row" style="grid-template-columns:120px 1fr;gap:10px;align-items:center">
            <input type="color" id="pick_ctaGlow" value="#22d3a9">
            <input type="range" id="alpha_ctaGlow" min="0" max="1" step="0.01" value="0.60">
          </div>" placeholder="rgba(34,211,169,.55)">
        </div>
      </div>

      <div style="margin-top:10px">
        <button class="btn" type="button" id="themePreviewBtn">Preview now</button>
        <span class="muted" style="margin-left:8px">Кнопка не зберігає, лише примусово оновлює прев’ю.</span>
      </div>
    </div>


    <div class="row">
      <div>
        <label>Review #1 image</label>
        <input type="file" name="review_r1" accept=".png,.jpg,.jpeg,.webp,.svg" />
        <div style="margin-top:8px">Current: <?php if(!empty($reviews['r1'])): ?><img src="<?= h(with_ver($reviews['r1'],$ver)) ?>" style="height:46px;border-radius:12px;vertical-align:middle"><?php else: ?><span class="muted">—</span><?php endif; ?></div>
      </div>
      <div>
        <label>Review #2 image</label>
        <input type="file" name="review_r2" accept=".png,.jpg,.jpeg,.webp,.svg" />
        <div style="margin-top:8px">Current: <?php if(!empty($reviews['r2'])): ?><img src="<?= h(with_ver($reviews['r2'],$ver)) ?>" style="height:46px;border-radius:12px;vertical-align:middle"><?php else: ?><span class="muted">—</span><?php endif; ?></div>
      </div>
      <div>
        <label>Review #3 image</label>
        <input type="file" name="review_r3" accept=".png,.jpg,.jpeg,.webp,.svg" />
        <div style="margin-top:8px">Current: <?php if(!empty($reviews['r3'])): ?><img src="<?= h(with_ver($reviews['r3'],$ver)) ?>" style="height:46px;border-radius:12px;vertical-align:middle"><?php else: ?><span class="muted">—</span><?php endif; ?></div>
      </div>
    </div>

    <div style="margin-top:12px">
      <button class="btn" type="submit">Save</button>
    </div>
  </form>
</div>

<div class="card" style="margin-top:14px">
  <h3 style="margin:0 0 10px">Saved swatches</h3>
  <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
    <input type="hidden" name="action" value="save_swatch">
    <div style="min-width:240px">
      <label>Swatch name</label>
      <input type="text" name="swatch_name" placeholder="My palette">
    </div>
    <button class="btn" type="submit">Save current as swatch</button>
  </form>

  <div style="height:12px"></div>

  <?php if(!empty($swatches)): ?>
    <div style="display:flex;flex-direction:column;gap:10px">
      <?php foreach($swatches as $sw): $t = $sw['theme'] ?? []; if(!is_array($t)) $t=[]; ?>
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid rgba(255,255,255,.10);border-radius:14px;padding:10px;background:rgba(255,255,255,.03)">
          <div style="display:flex;align-items:center;gap:10px">
            <div style="display:flex;gap:6px">
              <span class="sw" style="background:<?= h($t['btn1'] ?? '#7c5cff') ?>"></span>
              <span class="sw" style="background:<?= h($t['btn2'] ?? '#23d5ab') ?>"></span>
              <span class="sw" style="background:<?= h($t['cta1'] ?? '#22d3a9') ?>"></span>
              <span class="sw" style="background:<?= h($t['cta2'] ?? '#2cff8a') ?>"></span>
            </div>
            <div>
              <div style="font-weight:900"><?= h($sw['name'] ?? 'Palette') ?></div>
              <div class="muted" style="font-size:12px"><?= h(strtoupper((string)($sw['mode'] ?? 'night'))) ?></div>
            </div>
          </div>
          <div style="display:flex;gap:8px;align-items:center">
            <form method="post" style="margin:0">
              <input type="hidden" name="action" value="apply_swatch">
              <input type="hidden" name="swatch_id" value="<?= h($sw['id'] ?? '') ?>">
              <button class="btn" type="submit">Apply</button>
            </form>
            <form method="post" style="margin:0">
              <input type="hidden" name="action" value="delete_swatch">
              <input type="hidden" name="swatch_id" value="<?= h($sw['id'] ?? '') ?>">
              <button class="btn" type="submit" style="opacity:.8">Delete</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="muted">No swatches yet.</div>
  <?php endif; ?>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Preview (saved)</h3>
  <div class="muted" style="margin-bottom:10px">Після Save онови iframe (reload) — побачиш як виглядає на сайті.</div>
  <iframe src="/preview/visual.php?v=<?= (int)$ver ?>" style="width:100%;height:760px;border:1px solid rgba(255,255,255,.12);border-radius:16px;background:#0b1026"></iframe>


<div class="card">
  <h3 style="margin:0 0 10px">Home Builder</h3>
  <div class="muted" style="margin-bottom:10px">Візуальне редагування головної (клік по блоках + порядок для Desktop/Mobile).</div>
  <a class="btn" href="/admin/builder.php">Open Home Builder</a>
</div>

</div>

<script>
  const logoInput = document.querySelector('input[name="logo_file"]');
  const logoPrev = document.getElementById('logoPreview');
  if(logoInput && logoPrev){
    logoInput.addEventListener('change', ()=>{
      const f = logoInput.files && logoInput.files[0];
      if(!f) return;
      logoPrev.src = URL.createObjectURL(f);
    });
  }

  // Helpers for color pickers
  function rgbaToObj(str){
    str = String(str||'').trim();
    // hex
    if(str[0]==='#'){
      return {hex:str, a:1};
    }
    const m = str.match(/rgba?\(([^)]+)\)/i);
    if(!m) return {hex:'#ffffff', a:1};
    const parts = m[1].split(',').map(s=>s.trim());
    const r = parseFloat(parts[0]||'0'), g = parseFloat(parts[1]||'0'), b = parseFloat(parts[2]||'0');
    const a = parts.length>=4 ? parseFloat(parts[3]) : 1;
    const toHex = (n)=>('0'+Math.max(0,Math.min(255,Math.round(n))).toString(16)).slice(-2);
    return {hex:'#'+toHex(r)+toHex(g)+toHex(b), a: isNaN(a)?1:Math.max(0,Math.min(1,a))};
  }
  function hexToRgb(hex){
    hex = String(hex||'').replace('#','').trim();
    if(hex.length===3){ hex = hex.split('').map(c=>c+c).join(''); }
    if(hex.length!==6) return {r:255,g:255,b:255};
    return {r:parseInt(hex.slice(0,2),16), g:parseInt(hex.slice(2,4),16), b:parseInt(hex.slice(4,6),16)};
  }
  function setHiddenRgba(hiddenId, pickId, alphaId){
    const hid = document.getElementById(hiddenId);
    const pick = document.getElementById(pickId);
    const alpha = alphaId ? document.getElementById(alphaId) : null;
    if(!hid || !pick) return;
    const rgb = hexToRgb(pick.value);
    const a = alpha ? parseFloat(alpha.value||'1') : 1;
    hid.value = `rgba(${rgb.r},${rgb.g},${rgb.b},${a.toFixed(2)})`;
  }
  function initPicker(hiddenId, pickId, alphaId){
    const hid = document.getElementById(hiddenId);
    const pick = document.getElementById(pickId);
    const alpha = alphaId ? document.getElementById(alphaId) : null;
    if(!hid || !pick) return;
    const o = rgbaToObj(hid.value);
    pick.value = o.hex;
    if(alpha){ alpha.value = String(o.a.toFixed(2)); }
  }

  // Live theme preview (no save): postMessage to iframe
  const iframe = document.querySelector('iframe');

  // init pickers from saved values
  initPicker('theme_bg1','pick_bg1','alpha_bg1');
  initPicker('theme_bg2','pick_bg2','alpha_bg2');
  initPicker('theme_bg3','pick_bg3','alpha_bg3');
  initPicker('theme_btn1','pick_btn1','alpha_btn1');
  initPicker('theme_btn2','pick_btn2','alpha_btn2');
  // cta are hex
  const c1 = document.getElementById('pick_cta1'); if(c1){ const h=document.getElementById('theme_cta1'); if(h) c1.value = rgbaToObj(h.value).hex; }
  const c2 = document.getElementById('pick_cta2'); if(c2){ const h=document.getElementById('theme_cta2'); if(h) c2.value = rgbaToObj(h.value).hex; }
  initPicker('theme_ctaGlow','pick_ctaGlow','alpha_ctaGlow');


  function sendTheme(){
    // sync hidden fields from pickers
    setHiddenRgba('theme_bg1','pick_bg1','alpha_bg1');
    setHiddenRgba('theme_bg2','pick_bg2','alpha_bg2');
    setHiddenRgba('theme_bg3','pick_bg3','alpha_bg3');
    setHiddenRgba('theme_btn1','pick_btn1','alpha_btn1');
    setHiddenRgba('theme_btn2','pick_btn2','alpha_btn2');
    // hex cta
    const h1 = document.getElementById('theme_cta1'); const p1 = document.getElementById('pick_cta1');
    if(h1 && p1) h1.value = p1.value;
    const h2 = document.getElementById('theme_cta2'); const p2 = document.getElementById('pick_cta2');
    if(h2 && p2) h2.value = p2.value;
    setHiddenRgba('theme_ctaGlow','pick_ctaGlow','alpha_ctaGlow');


    if(!iframe || !iframe.contentWindow) return;
    const get = (name)=>{ const el=document.querySelector('[name="'+name+'"]'); return el?String(el.value||'').trim():''; };
    iframe.contentWindow.postMessage({
      type:'theme_preview',
      vars:{
        bg1:get('theme_bg1'),
        bg2:get('theme_bg2'),
        bg3:get('theme_bg3'),
        btn1:get('theme_btn1'),
        btn2:get('theme_btn2'),
        cta1:get('theme_cta1'),
        cta2:get('theme_cta2'),
        ctaGlow:get('theme_ctaGlow')
      }
    }, '*');
  }
    // bind picker controls
  ['pick_bg1','alpha_bg1','pick_bg2','alpha_bg2','pick_bg3','alpha_bg3',
   'pick_btn1','alpha_btn1','pick_btn2','alpha_btn2',
   'pick_cta1','pick_cta2','pick_ctaGlow','alpha_ctaGlow'].forEach(id=>{
    const el = document.getElementById(id);
    if(!el) return;
    el.addEventListener('input', ()=>{ sendTheme(); });
    el.addEventListener('change', ()=>{ sendTheme(); });
  });
    if(!el) return;
    el.addEventListener('input', ()=>{ sendTheme(); });
    el.addEventListener('change', ()=>{ sendTheme(); });
  });
  const pbtn = document.getElementById('themePreviewBtn');
  if(pbtn) pbtn.addEventListener('click', sendTheme);

  // send on load
  setTimeout(sendTheme, 300);
  // Instant preview for burger icons (before Save)
  function previewFile(inputName, previewId){
    const inp = document.querySelector('input[name="'+inputName+'"]');
    const el = document.getElementById(previewId);
    if(!inp || !el) return;
    inp.addEventListener('change', ()=>{
      const f = inp.files && inp.files[0];
      if(!f) return;
      const url = URL.createObjectURL(f);
      if(el.tagName === 'IMG'){
        el.src = url;
      } else {
        const im = document.createElement('img');
        im.id = previewId;
        im.src = url;
        im.style.height = '26px';
        im.style.width = '26px';
        im.style.objectFit = 'contain';
        el.parentNode.replaceChild(im, el);
      }
    });
  }
  previewFile('burger_desktop_file','burgerPrevDesktop');
  previewFile('burger_mobile_file','burgerPrevMobile');

</script>

<?php include __DIR__ . '/_footer.php'; ?>
