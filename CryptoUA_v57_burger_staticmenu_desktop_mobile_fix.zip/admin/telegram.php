<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
require __DIR__ . '/../tg/tg_lib.php';
include __DIR__ . '/_layout.php';

$ok=''; $err='';

$token = (string)cfg('TELEGRAM_BOT_TOKEN','');
$chat  = (string)cfg('TELEGRAM_CHAT_ID','');
$secret= (string)cfg('TG_WEBHOOK_SECRET','');

$base  = rtrim((string)cfg('BASE_URL',''), '/');
if (!$base) {
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? '';
  $base = $host ? ($scheme . '://' . $host) : '';
}

$webhookUrl = $base ? ($base . '/tg/webhook.php' . ($secret ? ('?token=' . urlencode($secret)) : '')) : '';

if($_SERVER['REQUEST_METHOD']==='POST'){
  $action = $_POST['action'] ?? 'save';
  try {
    if ($action === 'save') {
      $token = trim((string)($_POST['token'] ?? ''));
      $chat  = trim((string)($_POST['chat'] ?? ''));
      $secret= trim((string)($_POST['secret'] ?? ''));

      // Save to config.php (storage)
      cfg_set('TELEGRAM_BOT_TOKEN', $token);
      cfg_set('TELEGRAM_CHAT_ID', $chat);
      cfg_set('TG_WEBHOOK_SECRET', $secret);

      audit('TELEGRAM_SETTINGS_UPDATE', ['has_token'=> (bool)$token, 'chat'=>$chat ? 'set' : '']);
      $ok = 'Збережено ✅';

      $webhookUrl = $base ? ($base . '/tg/webhook.php' . ($secret ? ('?token=' . urlencode($secret)) : '')) : '';
    }

    if ($action === 'test') {
      $text = "✅ CryptoUA test message\n\n<code>".h(now_iso())."</code>";
      $res = tg_request('sendMessage', [
        'chat_id' => $chat,
        'text' => $text,
        'parse_mode' => 'HTML'
      ]);
      if (!($res['ok'] ?? false)) throw new Exception('Telegram error: ' . json_encode($res, JSON_UNESCAPED_UNICODE));
      audit('TELEGRAM_TEST_MESSAGE', []);
      $ok = 'Відправлено ✅';
    }
  } catch(Throwable $e){
    $err = $e->getMessage();
  }
}

?><div class="card">
  <h2 style="margin:0 0 6px">Telegram settings</h2>
  <div class="muted">Налаштування бота для заявок та кнопок “взяти в роботу / підтвердити оплату / виплачено”.</div>
  <?php if($ok): ?><div style="margin-top:10px" class="muted"><?= h($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div style="margin-top:10px;color:#ffb4b4"><?= h($err) ?></div><?php endif; ?>
</div>

<div class="card">
  <form method="post">
    <input type="hidden" name="action" value="save">
    <div class="row">
      <div><label class="muted">Bot token</label><input name="token" value="<?= h($token) ?>" placeholder="123456:ABC..."></div>
      <div><label class="muted">Chat ID</label><input name="chat" value="<?= h($chat) ?>" placeholder="-1001234567890"></div>
    </div>
    <div class="row">
      <div><label class="muted">Webhook secret (optional)</label><input name="secret" value="<?= h($secret) ?>" placeholder="random-string"></div>
      <div style="display:flex;align-items:end;gap:10px">
        <button class="pill" type="submit" style="border:none;cursor:pointer">Save</button>
      </div>
    </div>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 8px">Webhook</h3>
  <div class="muted">URL для setWebhook:</div>
  <div style="margin-top:8px"><input value="<?= h($webhookUrl) ?>" readonly></div>
  <div class="muted" style="margin-top:8px">Команда (curl):</div>
  <pre style="white-space:pre-wrap;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);padding:10px;border-radius:14px;margin:8px 0 0">
curl -s "https://api.telegram.org/botYOUR_TOKEN/setWebhook" -d "url=<?= h($webhookUrl) ?>"
</pre>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Test message</h3>
  <form method="post">
    <input type="hidden" name="action" value="test">
    <button class="pill" type="submit" style="border:none;cursor:pointer">Send test to Chat ID</button>
  </form>
</div>
