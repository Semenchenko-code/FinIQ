<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

$default_menu_items = [
  ['id'=>'rates','href'=>'#rates','label_uk'=>'Курс','label_en'=>'Rate','enabled'=>true],
  ['id'=>'how','href'=>'#how','label_uk'=>'Як це працює','label_en'=>'How it works','enabled'=>true],
  ['id'=>'advantages','href'=>'#advantages','label_uk'=>'Переваги','label_en'=>'Advantages','enabled'=>true],
  ['id'=>'limits','href'=>'#limits','label_uk'=>'Ліміти','label_en'=>'Limits','enabled'=>true],
  ['id'=>'reviews','href'=>'#reviews','label_uk'=>'Відгуки','label_en'=>'Reviews','enabled'=>true],
  ['id'=>'partners','href'=>'#partners','label_uk'=>'Партнери','label_en'=>'Partners','enabled'=>true],
  ['id'=>'faq','href'=>'#faq','label_uk'=>'FAQ','label_en'=>'FAQ','enabled'=>true],
  ['id'=>'contacts','href'=>'#contacts','label_uk'=>'Контакти','label_en'=>'Contacts','enabled'=>true],
];

$items = setting_get('menu_items', $default_menu_items);
if(is_string($items)) $items = json_decode($items, true);
if(!is_array($items) || !$items) $items = $default_menu_items;

$msg = '';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $raw = (string)($_POST['menu_items'] ?? '[]');
  $arr = json_decode($raw, true);
  if(!is_array($arr)) $arr = $default_menu_items;

  $clean = [];
  $seen = [];
  foreach($arr as $it){
    if(!is_array($it)) continue;
    $id = trim((string)($it['id'] ?? ''));
    if($id==='') continue;
    if(isset($seen[$id])) continue;
    $seen[$id]=true;
    $href = trim((string)($it['href'] ?? '#'));
    if($href==='') $href = '#';
    $clean[] = [
      'id'=>$id,
      'href'=>$href,
      'label_uk'=>trim((string)($it['label_uk'] ?? '')),
      'label_en'=>trim((string)($it['label_en'] ?? '')),
      'enabled'=>!empty($it['enabled']),
    ];
  }
  if(!$clean) $clean = $default_menu_items;

  setting_set('menu_items', $clean);
  setting_set('visual_ver', time());
  audit('MENU_BUILDER_SAVE', ['count'=>count($clean)]);
  $items = $clean;
  $msg = 'Saved ✅';
}

$ver = (int)setting_get('visual_ver', 0);
if($ver<=0) $ver = time();
?>
<div class="container">
  <div style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
    <div>
      <h2 style="margin:0 0 6px">Menu Builder</h2>
      <div class="muted">Перетягуй пункти, вмикай/вимикай, редагуй назви UA/EN.</div>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      <a class="pill" href="/admin/builder.php">Home Builder</a>
      <a class="pill" href="/admin/visual.php">Visual theme</a>
    </div>
  </div>

  <?php if($msg): ?><div class="ok" style="margin:12px 0"><?= h($msg) ?></div><?php endif; ?>

  <form method="post" id="menuForm">
    <input type="hidden" name="menu_items" id="menuItemsInp" value="<?= h(json_encode($items, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) ?>">

    <div style="display:grid;grid-template-columns:520px 1fr;gap:14px;align-items:start;margin-top:14px">
      <div class="card" style="padding:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
          <div style="font-weight:900">Items</div>
          <button class="btnPrimary" type="submit">Save</button>
        </div>

        <div id="menuList" style="margin-top:12px;display:flex;flex-direction:column;gap:10px"></div>

        <div class="muted" style="margin-top:10px;font-size:12px">Порада: href залишай як #advantages тощо.</div>
      </div>

      <div class="card" style="padding:0;overflow:hidden">
        <iframe src="/?menuPreview=1&amp;v=<?= h((string)$ver) ?>" style="width:100%;height:78vh;border:0"></iframe>
      </div>
    </div>
  </form>
</div>

<style>
.menuItem{
  padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);
  background:rgba(255,255,255,.03);
}
.menuItemHead{display:flex;align-items:center;justify-content:space-between;gap:10px}
.menuItemTitle{font-weight:900;cursor:grab}
.menuItem.dragging{opacity:.45}
.field{width:100%;padding:10px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.04);color:#fff}
.row2{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
</style>

<script>
(function(){
  var inp = document.getElementById('menuItemsInp');
  var list = document.getElementById('menuList');
  var items = [];
  try{ items = JSON.parse(inp.value||'[]'); }catch(e){ items=[]; }

  function sync(){ inp.value = JSON.stringify(items); }

  function render(){
    list.innerHTML = '';
    items.forEach(function(it, idx){
      var el = document.createElement('div');
      el.className = 'menuItem';
      el.draggable = true;
      el.dataset.idx = String(idx);

      el.innerHTML =
        '<div class="menuItemHead">' +
          '<div class="menuItemTitle">☰ ' + escapeHtml(it.id||('item'+idx)) + '</div>' +
          '<label style="display:flex;align-items:center;gap:8px"><input type="checkbox" '+(it.enabled?'checked':'')+' data-k="enabled"> <span class="muted">Enabled</span></label>' +
        '</div>' +
        '<div class="row2">' +
          '<input class="field" placeholder="Label UA" value="'+escapeAttr(it.label_uk||'')+'" data-k="label_uk">' +
          '<input class="field" placeholder="Label EN" value="'+escapeAttr(it.label_en||'')+'" data-k="label_en">' +
        '</div>' +
        '<div class="row2">' +
          '<input class="field" placeholder="href (#section)" value="'+escapeAttr(it.href||'#')+'" data-k="href">' +
          '<input class="field" placeholder="id" value="'+escapeAttr(it.id||'')+'" data-k="id">' +
        '</div>';

      el.addEventListener('input', function(e){
        var t = e.target;
        var k = t.getAttribute('data-k'); if(!k) return;
        items[idx][k] = t.type==='checkbox' ? t.checked : t.value;
        sync();
      });
      el.addEventListener('change', function(e){
        var t = e.target;
        var k = t.getAttribute('data-k'); if(!k) return;
        items[idx][k] = t.type==='checkbox' ? t.checked : t.value;
        sync();
      });

      // DnD
      el.addEventListener('dragstart', function(e){
        el.classList.add('dragging');
        e.dataTransfer.setData('text/plain', String(idx));
      });
      el.addEventListener('dragend', function(){ el.classList.remove('dragging'); });

      el.addEventListener('dragover', function(e){ e.preventDefault(); });
      el.addEventListener('drop', function(e){
        e.preventDefault();
        var from = parseInt(e.dataTransfer.getData('text/plain')||'-1',10);
        var to = idx;
        if(from<0 || from===to) return;
        var moved = items.splice(from,1)[0];
        items.splice(to,0,moved);
        sync(); render();
      });

      list.appendChild(el);
    });
  }

  function escapeHtml(s){ return String(s).replace(/[&<>"]/g,function(c){return({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]);}); }
  function escapeAttr(s){ return escapeHtml(s).replace(/'/g,'&#39;'); }

  render();
  sync();
})();
</script>
<?php include __DIR__ . '/_footer.php'; ?>
