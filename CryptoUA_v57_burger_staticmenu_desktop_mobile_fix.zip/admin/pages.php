<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';


$pdo = db();
$ok='';

/* Ensure system pages exist (Terms / Privacy / KYC-AML) */
function ensure_system_pages(PDO $pdo){
  $defs = [
    ['slug'=>'terms','uk_title'=>'Умови','en_title'=>'Terms',
      'uk_body'=>"Тут будуть умови використання сервісу.\n\n(Текст можна змінити в адмінці.)",
      'en_body'=>"Service terms will be here.\n\n(You can edit this in admin.)"],
    ['slug'=>'privacy','uk_title'=>'Конфіденційність','en_title'=>'Privacy',
      'uk_body'=>"Тут буде політика конфіденційності.\n\n(Текст можна змінити в адмінці.)",
      'en_body'=>"Privacy policy will be here.\n\n(You can edit this in admin.)"],
    ['slug'=>'kyc-aml','uk_title'=>'KYC / AML','en_title'=>'KYC / AML',
      'uk_body'=>"Тут буде інформація щодо KYC/AML.\n\n(Текст можна змінити в адмінці.)",
      'en_body'=>"KYC/AML information will be here.\n\n(You can edit this in admin.)"],
  ];
  $chk = $pdo->prepare("SELECT id FROM pages WHERE slug=? AND lang=? LIMIT 1");
  $ins = $pdo->prepare("INSERT INTO pages(lang,slug,title,body,created_at,updated_at) VALUES(?,?,?,?,?,?)");
  foreach($defs as $d){
    foreach(['uk','en'] as $lng){
      $chk->execute([$d['slug'],$lng]);
      $ex = $chk->fetch();
      if(!$ex){
        $title = ($lng==='uk') ? $d['uk_title'] : $d['en_title'];
        $body  = ($lng==='uk') ? $d['uk_body']  : $d['en_body'];
        $ins->execute([$lng,$d['slug'],$title,$body,now_iso(),now_iso()]);
      }
    }
  }
}
ensure_system_pages($pdo);



if($_SERVER['REQUEST_METHOD']==='POST'){
  $action = $_POST['action'] ?? '';
  if($action==='save'){
    $id = (int)($_POST['id'] ?? 0);
    $lang = ($_POST['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';
    $slug = preg_replace('/[^a-z0-9\-]/','', strtolower(trim($_POST['slug'] ?? '')));
    $title = trim($_POST['title'] ?? '');
    $body = trim($_POST['body'] ?? '');
    if(!$slug) $slug = 'page-' . time();
    if($id>0){
      $pdo->prepare("UPDATE pages SET lang=?, slug=?, title=?, body=?, updated_at=? WHERE id=?")
          ->execute([$lang,$slug,$title,$body,now_iso(),$id]);
    } else {
      $pdo->prepare("INSERT INTO pages(lang,slug,title,body,created_at,updated_at) VALUES(?,?,?,?,?,?)")
          ->execute([$lang,$slug,$title,$body,now_iso(),now_iso()]);
      $id = (int)$pdo->lastInsertId();
    }
    audit('PAGE_SAVE', ['id'=>$id,'slug'=>$slug,'lang'=>$lang]);
    $ok='Saved ✅';
  }
  if($action==='del'){
    $id=(int)($_POST['id'] ?? 0);
    $pdo->prepare("DELETE FROM pages WHERE id=?")->execute([$id]);
    audit('PAGE_DELETE', ['id'=>$id]);
    $ok='Deleted ✅';
  }
}

$edit = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$page = ['id'=>0,'lang'=>'uk','slug'=>'','title'=>'','body'=>''];
if($edit>0){
  $st=$pdo->prepare("SELECT * FROM pages WHERE id=?"); $st->execute([$edit]);
  $p=$st->fetch(); if($p) $page=$p;
}
$list = $pdo->query("SELECT id,lang,slug,title,updated_at FROM pages ORDER BY id DESC")->fetchAll();

?><div class="card">
  <h2 style="margin:0 0 6px">Pages</h2>
  <div class="muted">Доступ: /p.php?slug=...&lang=uk|en</div>
  <?php if($ok): ?><div class="muted" style="margin-top:8px"><?= h($ok) ?></div><?php endif; ?>
</div>

<div class="card">
  <h3 style="margin:0 0 10px"><?= $page['id']?('Edit #'.(int)$page['id']):'Add page' ?></h3>
  <form method="post">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?= (int)$page['id'] ?>">
    <div class="row">
      <div>
        <label class="muted">Lang</label>
        <select name="lang">
          <option value="uk" <?= ($page['lang']??'uk')==='uk'?'selected':'' ?>>UK</option>
          <option value="en" <?= ($page['lang']??'uk')==='en'?'selected':'' ?>>EN</option>
        </select>
      </div>
      <div>
        <label class="muted">Slug</label>
        <input name="slug" value="<?= h($page['slug']) ?>" placeholder="terms">
      </div>
    </div>
    <div style="height:10px"></div>
    <label class="muted">Title</label>
    <input name="title" value="<?= h($page['title']) ?>">
    <div style="height:10px"></div>
    <label class="muted">Body</label>
    <textarea name="body"><?= h($page['body']) ?></textarea>
    <div style="height:10px"></div>
    <button class="btn" type="submit">Save</button>
    <a class="btn2" href="/admin/pages.php">New</a>
  </form>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">All pages</h3>
  <table>
    <tr><th>ID</th><th>Lang</th><th>Slug</th><th>Title</th><th>Updated</th><th></th></tr>
    <?php foreach($list as $p): ?>
      <tr>
        <td>#<?= (int)$p['id'] ?></td>
        <td class="muted"><?= h($p['lang']) ?></td>
        <td><a href="/p.php?slug=<?= h($p['slug']) ?>&lang=<?= h($p['lang']) ?>" target="_blank"><?= h($p['slug']) ?></a></td>
        <td><?= h($p['title']) ?></td>
        <td class="muted"><?= h($p['updated_at']) ?></td>
        <td style="display:flex;gap:8px;flex-wrap:wrap">
          <a class="btn2" href="/admin/pages.php?edit=<?= (int)$p['id'] ?>">Edit</a>
          <form method="post" onsubmit="return confirm('Delete?')">
            <input type="hidden" name="action" value="del">
            <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
            <button class="btn2" type="submit">Delete</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
