<?php
require_once __DIR__ . '/../helpers.php';
require_role('admin');
include __DIR__ . '/_layout.php';

function save_upload(string $field, string $prefix): ?string {
  if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) return null;
  $tmp = $_FILES[$field]['tmp_name'];
  $name = basename($_FILES[$field]['name']);
  $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
  if (!in_array($ext, ['png','jpg','jpeg','webp','svg'], true)) return null;
  $fn = $prefix . '_' . date('Ymd_His') . '.' . $ext;
  $dir = __DIR__ . '/../uploads/';
  if(!is_dir($dir)) { @mkdir($dir, 0755, true); }
  $dest = $dir . $fn;
  if (!move_uploaded_file($tmp, $dest)) return null;
  return '/uploads/' . $fn;
}


$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';
$key  = 'calc_ui_' . $lang;

$defaults = [
  'label_currency' => $lang==='en' ? 'Currency' : 'Валюта',
  'label_amount'   => $lang==='en' ? 'Amount'   : 'Кількість',
  'placeholder_phone' => $lang==='en' ? 'Phone' : 'Телефон',
  'btn_submit'     => $lang==='en' ? 'EXCHANGE' : 'ПОМІНЯТИ ВАЛЮТУ',
  'aria_swap'      => $lang==='en' ? 'Swap' : 'Поміняти місцями',
  'fee_label'      => $lang==='en' ? 'Service fee' : 'Комісія сервісу',
  'show_fee'       => true,
  'show_fee_amount'=> false,
];

$ui = setting_get($key, $defaults);
$icons = setting_get('calc_icons', ['UAH'=>'','USDT'=>'']);
if(!is_array($icons)) $icons=['UAH'=>'','USDT'=>''];
if (!is_array($ui)) $ui = $defaults;

$prevVer = (int)setting_get('calc_preview_ver', 0);
if($prevVer<=0) $prevVer = time();

$ok=''; $err='';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try{
    $ui['label_currency'] = trim((string)($_POST['label_currency'] ?? $defaults['label_currency']));
    $ui['label_amount']   = trim((string)($_POST['label_amount'] ?? $defaults['label_amount']));
    $ui['placeholder_phone'] = trim((string)($_POST['placeholder_phone'] ?? $defaults['placeholder_phone']));
    $ui['btn_submit']     = trim((string)($_POST['btn_submit'] ?? $defaults['btn_submit']));
    $ui['aria_swap']      = trim((string)($_POST['aria_swap'] ?? $defaults['aria_swap']));
    $ui['fee_label']      = trim((string)($_POST['fee_label'] ?? $defaults['fee_label']));
    $ui['show_fee']       = isset($_POST['show_fee']);
    $ui['show_fee_amount']= isset($_POST['show_fee_amount']);

    // tiny sanitize
    foreach(['label_currency','label_amount','placeholder_phone','btn_submit','aria_swap','fee_label'] as $k){
      $ui[$k] = mb_substr($ui[$k], 0, 120);
    }

    // icons upload
    $changed = [];
    $map = [
      'icon_uah'  => 'UAH',
      'icon_usdt' => 'USDT',
      'icon_btc'  => 'BTC',
      'icon_eth'  => 'ETH',
      'icon_usdc' => 'USDC',
      'icon_usd'  => 'USD',
      'icon_eur'  => 'EUR',
    ];
    foreach($map as $field=>$code){
      $p = save_upload($field, 'icon_' . strtolower($code));
      if($p){ $icons[$code] = $p; $changed[$code] = $p; }
    }

    $customCode = strtoupper(trim((string)($_POST['icon_custom_code'] ?? '')));
    if($customCode && preg_match('/^[A-Z0-9_\-]{2,10}$/', $customCode)){
      $p = save_upload('icon_custom_file', 'icon_' . strtolower($customCode));
      if($p){ $icons[$customCode] = $p; $changed[$customCode] = $p; }
    }

    setting_set('calc_icons', $icons);
    if(!empty($changed)){
      setting_set('calc_icons_ver', time());
      audit('CALC_ICON_SAVE', ['changed'=>$changed]);
    }

    setting_set($key, $ui);
    audit('CALC_UI_SAVE', ['lang'=>$lang]);
    setting_set('calc_preview_ver', time());
    $ok = "Збережено ✅";
  }catch(Throwable $e){
    $err = $e->getMessage();
  }
}

?>
<div class="card">
  <h2 style="margin:0 0 8px">Calculator UI (<?= strtoupper($lang) ?>)</h2>
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 10px">
    <a class="pill" href="/admin/calculator.php?lang=uk">UA</a>
    <a class="pill" href="/admin/calculator.php?lang=en">EN</a>
  </div>

  <?php if($ok): ?><div class="ok"><?= h($ok) ?></div><?php endif; ?>
  <?php if($err): ?><div class="err"><?= h($err) ?></div><?php endif; ?>

  <form method="post" enctype="multipart/form-data" style="margin-top:10px">
    <div class="row">
      <div>
        <label>Label “Currency”</label>
        <input name="label_currency" value="<?= h($ui['label_currency'] ?? '') ?>">
      </div>
      <div>
        <label>Label “Amount”</label>
        <input name="label_amount" value="<?= h($ui['label_amount'] ?? '') ?>">
      </div>
    </div>

    <div class="row">
      <div>
        <label>Phone placeholder</label>
        <input name="placeholder_phone" value="<?= h($ui['placeholder_phone'] ?? '') ?>">
      </div>
      <div>
        <label>Submit button text</label>
        <input name="btn_submit" value="<?= h($ui['btn_submit'] ?? '') ?>">
      </div>
    </div>

    <div class="row">
      <div>
        <label>Swap aria-label</label>
        <input name="aria_swap" value="<?= h($ui['aria_swap'] ?? '') ?>">
      </div>
      <div>
        <label>Fee label</label>
        <input name="fee_label" value="<?= h($ui['fee_label'] ?? '') ?>">
      </div>
    </div>

    <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap;margin-top:10px">
      <label style="display:flex;gap:10px;align-items:center">
        <input type="checkbox" name="show_fee" <?= !empty($ui['show_fee'])?'checked':'' ?> style="width:auto">
        Show fee line in calculator
      </label>

      </div>

    
    <div style="margin-top:14px">
      <div style="font-weight:900;margin-bottom:8px">Currency icons (Calculator)</div>

      <div class="row">
        <div>
          <label>UAH icon (png/jpg/webp/svg)</label>
          <input type="file" name="icon_uah" accept=".png,.jpg,.jpeg,.webp,.svg" />
          <div style="margin-top:8px;opacity:.9">Current: <?php if(!empty($icons['UAH'])): ?><img src="<?= h($icons['UAH']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
        </div>
        <div>
          <label>USDT icon (png/jpg/webp/svg)</label>
          <input type="file" name="icon_usdt" accept=".png,.jpg,.jpeg,.webp,.svg" />
          <div style="margin-top:8px;opacity:.9">Current: <?php if(!empty($icons['USDT'])): ?><img src="<?= h($icons['USDT']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
        </div>
      </div>

      <div class="row" style="margin-top:12px">
        <div>
          <label>BTC icon</label>
          <input type="file" name="icon_btc" accept=".png,.jpg,.jpeg,.webp,.svg" />
          <div style="margin-top:8px;opacity:.9">Current: <?php if(!empty($icons['BTC'])): ?><img src="<?= h($icons['BTC']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
        </div>
        <div>
          <label>ETH icon</label>
          <input type="file" name="icon_eth" accept=".png,.jpg,.jpeg,.webp,.svg" />
          <div style="margin-top:8px;opacity:.9">Current: <?php if(!empty($icons['ETH'])): ?><img src="<?= h($icons['ETH']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
        </div>
      </div>

      <div class="row" style="margin-top:12px">
        <div>
          <label>USDC icon</label>
          <input type="file" name="icon_usdc" accept=".png,.jpg,.jpeg,.webp,.svg" />
          <div style="margin-top:8px;opacity:.9">Current: <?php if(!empty($icons['USDC'])): ?><img src="<?= h($icons['USDC']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
        </div>
        <div>
          <label>USD / EUR icons</label>
          <div class="row" style="grid-template-columns:1fr 1fr;gap:10px">
            <div>
              <input type="file" name="icon_usd" accept=".png,.jpg,.jpeg,.webp,.svg" />
              <div style="margin-top:8px;opacity:.9">USD: <?php if(!empty($icons['USD'])): ?><img src="<?= h($icons['USD']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
            </div>
            <div>
              <input type="file" name="icon_eur" accept=".png,.jpg,.jpeg,.webp,.svg" />
              <div style="margin-top:8px;opacity:.9">EUR: <?php if(!empty($icons['EUR'])): ?><img src="<?= h($icons['EUR']) ?>" style="height:22px;vertical-align:middle"><?php else: ?>—<?php endif; ?></div>
            </div>
          </div>
        </div>
      </div>

      <div class="card" style="margin-top:12px">
        <div style="font-weight:900;margin-bottom:8px">Custom currency icon</div>
        <div class="row" style="grid-template-columns:160px 1fr;gap:12px;align-items:end">
          <div>
            <label>Code</label>
            <input type="text" name="icon_custom_code" placeholder="e.g. TON" maxlength="10" />
          </div>
          <div>
            <label>Icon file</label>
            <input type="file" name="icon_custom_file" accept=".png,.jpg,.jpeg,.webp,.svg" />
          </div>
        </div>
        <div style="opacity:.75;margin-top:8px">Після Save іконка стане доступною в калькуляторі (якщо є напрям UAH⇄CODE).</div>
      </div>
    </div>

    <div style="margin-top:12px">

      <button class="btn" type="submit">Save</button>
    </div>

    <div class="card" style="margin-top:14px">
  <h3 style="margin:0 0 10px">Preview (saved settings)</h3>
  <div style="opacity:.85;margin:0 0 10px">Натисни <b>Save</b>, потім онови preview (reload в iframe).</div>
  <iframe src="/preview/calculator.php?lang=<?= h($lang) ?>&v=<?= (int)$prevVer ?>" style="width:100%;height:560px;border:1px solid rgba(255,255,255,.12);border-radius:14px;background:#0b1026"></iframe>
</div>
<p style="opacity:.85;margin:12px 0 0">
      This editor changes labels/placeholder/button text and fee line visibility. Fees themselves are set per direction in <b>Rates &amp; Fees</b>.
    </p>
  </form>
</div>
<?php include __DIR__ . '/_footer.php'; ?>
