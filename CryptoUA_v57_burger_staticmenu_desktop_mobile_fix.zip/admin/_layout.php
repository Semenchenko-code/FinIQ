<?php
require_once __DIR__ . '/../helpers.php';
$u = require_login();
?><!doctype html>
<html lang="uk"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>CryptoUA Admin</title>
<style>
  body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;background:#070a18;color:#e8ecff;margin:0}
  a{color:#a9b2ff;text-decoration:none}
  .top{display:flex;justify-content:space-between;align-items:center;padding:14px 18px;border-bottom:1px solid rgba(255,255,255,.12);background:#0b1030}
  .wrap{max-width:1100px;margin:0 auto;padding:18px}
  .nav{display:flex;flex-wrap:wrap;gap:10px}
  .pill{padding:8px 10px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.04)}
  .card{border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.03);border-radius:16px;padding:14px;margin:14px 0}
  input,select,textarea{width:100%;padding:10px 12px;border-radius:14px;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.04);color:#e8ecff;outline:none}
  textarea{min-height:110px}
  .row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
  .btn{display:inline-block;padding:10px 14px;border-radius:14px;border:none;cursor:pointer;background:linear-gradient(135deg, rgba(124,92,255,.95), rgba(35,213,171,.95));color:#071022;font-weight:800}
  .btn2{display:inline-block;padding:10px 14px;border-radius:14px;border:1px solid rgba(255,255,255,.14);cursor:pointer;background:transparent;color:#e8ecff}
  table{width:100%;border-collapse:collapse}
  th,td{padding:10px;border-bottom:1px solid rgba(255,255,255,.10);text-align:left;vertical-align:top}
  .muted{color:#a9b2d6}
  .tag{padding:3px 8px;border-radius:999px;border:1px solid rgba(255,255,255,.14);font-size:12px}
</style>
</head><body>
<div class="top">
  <div>
    <strong>CryptoUA Admin</strong>
    <span class="muted">— <?= h($u['username']) ?> (<?= h($u['role']) ?>)</span>
  </div>
  <div class="nav">
    <a class="pill" href="/admin/dashboard.php">Dashboard</a>
    <a class="pill" href="/admin/orders.php">Orders</a>
    <?php if(($u['role']??'')==='admin'): ?>
      <a class="pill" href="/admin/rates.php">Rates & Fees</a>
      <a class="pill" href="/admin/directions.php">Directions</a>
      <a class="pill" href="/admin/telegram.php">Telegram</a>
      <a class="pill" href="/admin/content.php">Content</a>
      <a class="pill" href="/admin/calculator.php">Calculator</a>
      <a class="pill" href="/admin/media.php">Media</a>
      <a class="pill" href="/admin/branding.php">Branding</a>
      <a class="pill" href="/admin/visual.php">Visual editor</a>
      <a class="pill" href="/admin/builder.php">Home Builder</a>
      <a class="pill" href="/admin/menu_builder.php">Menu</a>
      <a class="pill" href="/admin/blocks.php">Blocks</a>
      <a class="pill" href="/admin/menu_builder.php">Menu Builder</a>
      <a class="pill" href="/admin/pages.php">Pages</a>
      <a class="pill" href="/admin/seo.php">SEO</a>
      <a class="pill" href="/admin/users.php">Users</a>
      <a class="pill" href="/admin/audit.php">Audit</a>
    <?php endif; ?>
    <a class="pill" href="/admin/logout.php">Logout</a>
  </div>
</div>
<div class="wrap">
