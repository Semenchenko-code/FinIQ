<?php
require_once __DIR__ . '/../helpers.php';
include __DIR__ . '/_layout.php';

$pdo = db();
$cnt = $pdo->query("SELECT status, COUNT(*) c FROM orders GROUP BY status")->fetchAll();
$latest = $pdo->query("SELECT id, created_at, status, mode, from_amount, from_asset, to_amount, to_asset FROM orders ORDER BY id DESC LIMIT 10")->fetchAll();

?><div class="card">
  <h2 style="margin:0 0 6px">Dashboard</h2>
  <div class="muted">Швидка статистика по заявках</div>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Статуси</h3>
  <div style="display:flex;gap:10px;flex-wrap:wrap">
    <?php foreach($cnt as $r): ?>
      <span class="tag"><?= h($r['status']) ?>: <strong><?= (int)$r['c'] ?></strong></span>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <h3 style="margin:0 0 10px">Останні заявки</h3>
  <table>
    <tr><th>ID</th><th>Created</th><th>Status</th><th>Direction</th><th>Amounts</th></tr>
    <?php foreach($latest as $o): ?>
      <tr>
        <td><a href="/admin/orders.php?view=<?= (int)$o['id'] ?>">#<?= (int)$o['id'] ?></a></td>
        <td class="muted"><?= h($o['created_at']) ?></td>
        <td><span class="tag"><?= h($o['status']) ?></span></td>
        <td class="muted"><?= h($o['mode']) ?></td>
        <td><?= h($o['from_amount'].' '.$o['from_asset'].' → '.$o['to_amount'].' '.$o['to_asset']) ?></td>
      </tr>
    <?php endforeach; ?>
  </table>
</div>

<?php include __DIR__ . '/_footer.php'; ?>
