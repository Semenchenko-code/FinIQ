<?php
require_once __DIR__ . '/../helpers.php';
require __DIR__ . '/../tg/tg_lib.php';

if (!is_installed()) json_out(['error'=>'not_installed'], 400);

$body = json_decode(file_get_contents('php://input'), true) ?: [];
$lang = ($body['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';
$quoteId = (int)($body['quoteId'] ?? 0);
$mode = $body['mode'] ?? 'CRYPTO_TO_UAH';

$from = $body['from'] ?? [];
$to = $body['to'] ?? [];
$name = trim((string)($body['name'] ?? ''));
$contact = trim((string)($body['contact'] ?? ''));
if($contact==='') json_out(['error'=>'contact_required'], 400);
$payout = trim((string)($body['payout'] ?? ''));

$pdo = db();
$q = $pdo->prepare("SELECT * FROM quotes WHERE id=?");
$q->execute([$quoteId]);
$quote = $q->fetch();
if (!$quote) json_out(['error'=>'quote_not_found'], 400);
if ((int)$quote['expires_at_ms'] <= (int)(microtime(true)*1000)) json_out(['error'=>'quote_expired'], 400);

$fromAsset = (string)($from['asset'] ?? $quote['from_asset']);
$toAsset = (string)($to['asset'] ?? $quote['to_asset']);
$fromAmount = (float)($from['amount'] ?? $quote['from_amount']);
$toAmount = (float)($to['amount'] ?? $quote['to_amount']);

$pdo->prepare("INSERT INTO orders(created_at, status, mode, quote_id, from_asset, to_asset, from_amount, to_amount, fee_pct, name, contact, payout, notes, tg_message_id, tg_chat_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
    ->execute([now_iso(), 'NEW', $mode, $quoteId, $fromAsset, $toAsset, $fromAmount, $toAmount, (float)$quote['fee_pct'], $name, $contact, $payout, '', null, null]);

$orderId = (int)$pdo->lastInsertId();

$chatId = cfg('TELEGRAM_CHAT_ID','');
$sent = null;
if ($chatId && cfg('TELEGRAM_BOT_TOKEN','')) {
  $o = $pdo->query("SELECT * FROM orders WHERE id=".(int)$orderId)->fetch();
  $payload = [
    'chat_id' => $chatId,
    'text' => tg_order_text($o),
    'parse_mode' => 'Markdown',
    'reply_markup' => tg_keyboard_for_order($orderId, 'NEW')
  ];
  $sent = tg_request('sendMessage', $payload);
  if (($sent['ok'] ?? false) && isset($sent['result']['message_id'])) {
    $mid = (int)$sent['result']['message_id'];
    $pdo->prepare("UPDATE orders SET tg_message_id=?, tg_chat_id=? WHERE id=?")->execute([$mid, (string)$chatId, $orderId]);
  }
}

json_out([
  'orderId' => $orderId,
  'status' => 'NEW',
  'quoteExpiresAt' => (int)$quote['expires_at_ms'],
  'telegramOk' => (bool)($sent['ok'] ?? false)
]);
