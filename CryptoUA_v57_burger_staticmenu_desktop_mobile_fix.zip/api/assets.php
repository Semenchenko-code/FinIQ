<?php
require_once __DIR__ . '/../helpers.php';
if (!is_installed()) json_out(['error'=>'not_installed'], 400);

$dirs = directions_list(true); // enabled only
$assets = [];
$pairs = [];

foreach($dirs as $d){
  $fa = strtoupper(trim((string)($d['from_asset'] ?? '')));
  $ta = strtoupper(trim((string)($d['to_asset'] ?? '')));
  if(!$fa || !$ta) continue;
  $assets[$fa]=true; $assets[$ta]=true;
  $pairs[] = ['from'=>$fa,'to'=>$ta,'rate'=>(float)($d['rate']??0),'feePct'=>(float)($d['fee_pct']??0),'min'=>$d['min_amount'],'max'=>$d['max_amount']];
}

$icons = setting_get('calc_icons', []);
if(!is_array($icons)) $icons = [];
$ver = (int)setting_get('calc_icons_ver', 0);

$outIcons = [];
foreach($icons as $k=>$v){
  $k = strtoupper(trim((string)$k));
  $v = (string)$v;
  if($k==='' || $v==='') continue;
  if($ver>0){
    $sep = (strpos($v,'?')===false) ? '?' : '&';
    $v = $v . $sep . 'v=' . $ver;
  }
  $outIcons[$k] = $v;
}

$assetList = array_values(array_unique(array_keys($assets)));
sort($assetList);

json_out([
  'assets'=>$assetList,
  'directions'=>$pairs,
  'icons'=>$outIcons,
  'updatedAt'=>now_iso()
]);
