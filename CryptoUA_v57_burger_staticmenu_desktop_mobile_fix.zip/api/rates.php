<?php
require_once __DIR__ . '/../helpers.php';
if (!is_installed()) json_out(['error'=>'not_installed'], 400);

// Directions drive the calculator (admin can create new pairs).
$dirs = directions_list(true);

// Backward compatible rates map (*_UAH) for older JS/widgets.
$rates = [];
foreach ($dirs as $d){
  if (($d['to_asset'] ?? '') === 'UAH' && (int)($d['enabled'] ?? 0) === 1){
    $rates[(string)$d['from_asset'] . '_UAH'] = (float)($d['rate'] ?? 0);
  }
}

$quote = setting_get('quote', ['quoteTtlSec'=>300]);

json_out([
  'directions' => $dirs,
  'rates' => $rates,
  'quoteTtlSec' => (int)($quote['quoteTtlSec'] ?? 300),
  'updatedAt' => now_iso()
]);
