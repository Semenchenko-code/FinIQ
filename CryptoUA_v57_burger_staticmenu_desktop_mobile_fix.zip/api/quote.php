<?php
require_once __DIR__ . '/../helpers.php';
if (!is_installed()) json_out(['error'=>'not_installed'], 400);

$body = json_decode(file_get_contents('php://input'), true) ?: [];
$mode = $body['mode'] ?? 'CRYPTO_TO_UAH';
$fromAsset = strtoupper(trim((string)($body['fromAsset'] ?? 'USDT')));
$toAsset   = strtoupper(trim((string)($body['toAsset']   ?? 'UAH')));
$fromAmount = (float)($body['fromAmount'] ?? 0);

if ($fromAmount <= 0) json_out(['error'=>'bad_amount'], 400);

// Direction is selected explicitly (fromAsset/toAsset)

$dir = direction_get($fromAsset, $toAsset, true);
if (!$dir) json_out(['error'=>'direction_not_found'], 400);

$rate = (float)($dir['rate'] ?? 0);
$feePct = (float)($dir['fee_pct'] ?? 0.8);
$min = $dir['min_amount'] ?? null;
$max = $dir['max_amount'] ?? null;

if ($rate <= 0) json_out(['error'=>'rate_not_set'], 400);
if ($min !== null && $fromAmount < (float)$min) json_out(['error'=>'below_min','min_amount'=>(float)$min,'asset'=>$fromAsset], 400);
if ($max !== null && $fromAmount > (float)$max) json_out(['error'=>'above_max','max_amount'=>(float)$max,'asset'=>$fromAsset], 400);

$gross = $fromAmount * $rate;
$net = $gross * (1 - ($feePct/100));

$quoteCfg = setting_get('quote', ['quoteTtlSec'=>300]);
$ttl = max(30, (int)($quoteCfg['quoteTtlSec'] ?? 300));
$expiresAt = (int)(microtime(true) * 1000) + $ttl * 1000;

$pdo = db();
$pdo->prepare("INSERT INTO quotes(created_at, expires_at_ms, mode, from_asset, to_asset, from_amount, to_amount, rate, fee_pct) VALUES(?,?,?,?,?,?,?,?,?)")
    ->execute([now_iso(), $expiresAt, $mode, $fromAsset, $toAsset, $fromAmount, $net, $rate, $feePct]);

$id = (int)$pdo->lastInsertId();
json_out([
  'id'=>$id,
  'expiresAt'=>$expiresAt,
  'rate'=>$rate,
  'feePct'=>$feePct,
  'toAmount'=>$net
]);
