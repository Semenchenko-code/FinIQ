<?php
require_once __DIR__ . '/../helpers.php';
require_login();
$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';

$logo = (string)setting_get('brand_logo', '/assets/logo.svg');
$burgerD = (string)setting_get('burger_icon_desktop', (string)setting_get('burger_icon',''));
$burgerM = (string)setting_get('burger_icon_mobile','');
if($burgerM==='') $burgerM = $burgerD;
if($burgerD==='') $burgerD = (string)setting_get('brand_burger_icon','');
if($burgerM==='') $burgerM = $burgerD;
$ver = (int)setting_get('brand_assets_ver', 0);

function with_ver(string $url, int $ver): string {
  if($ver<=0 || !$url) return $url;
  $sep = (strpos($url,'?')===false) ? '?' : '&';
  return $url . $sep . 'v=' . $ver;
}
$logoV = with_ver($logo, $ver);
$burgerDV = with_ver($burgerD, $ver);
$burgerMV = with_ver($burgerM, $ver);
?><!doctype html>
<html lang="<?= $lang ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <link rel="stylesheet" href="/site.css" />
  <link rel="stylesheet" href="/site.mobile.css" media="(max-width: 820px)" />
  <style>
    body{margin:0;padding:12px;background:#0b1026}
  </style>
</head>
<body>
<header class="header">
  <div class="container header__inner">
    <a class="logo" href="#" aria-label="CryptoUA">
      <img class="logo__img" src="<?= h($logoV) ?>" alt="CryptoUA" style="height:30px" />
    </a>
    <div class="lang">
      <a class="lang__btn <?= $lang==='uk'?'active':'' ?>" href="#">UA</a>
      <a class="lang__btn <?= $lang==='en'?'active':'' ?>" href="#">EN</a>
    </div>
    <button class="burgerBtn" type="button" aria-label="Menu" aria-expanded="false">
      <?php if($burgerDV || $burgerMV): ?>
        <?php if($burgerDV): ?><img class="burgerBtn__icon burgerBtn__icon--desktop" src="<?= h($burgerDV) ?>" alt="menu" /><?php endif; ?>
        <?php if($burgerMV): ?><img class="burgerBtn__icon burgerBtn__icon--mobile" src="<?= h($burgerMV) ?>" alt="menu" /><?php endif; ?>
      <?php else: ?>
        <span></span><span></span><span></span>
      <?php endif; ?>
    </button>
  </div>
</header>
</body>
</html>
