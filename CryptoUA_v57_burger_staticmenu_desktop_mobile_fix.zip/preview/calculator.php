<?php
require_once __DIR__ . '/../helpers.php';
require_login(); // admin or operator can preview
$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';

$calcUi = setting_get('calc_ui_' . $lang, [
  'label_currency' => $lang==='en' ? 'Currency' : 'Валюта',
  'label_amount'   => $lang==='en' ? 'Amount' : 'Кількість',
  'placeholder_phone' => $lang==='en' ? 'Phone' : 'Телефон',
  'btn_submit'     => $lang==='en' ? 'EXCHANGE' : 'ПОМІНЯТИ ВАЛЮТУ',
  'aria_swap'      => $lang==='en' ? 'Swap' : 'Поміняти місцями',
  'fee_label'      => $lang==='en' ? 'Service fee' : 'Комісія сервісу',
  'show_fee'       => true,
]);
if (!is_array($calcUi)) $calcUi = [];

$calcIcons = setting_get('calc_icons', ['UAH'=>'','USDT'=>'']);
if (!is_array($calcIcons)) $calcIcons = ['UAH'=>'','USDT'=>''];
$calcIconsVer = (int)setting_get('calc_icons_ver', 0);
$prevVer = (int)setting_get('calc_preview_ver', 0);
if($prevVer<=0) $prevVer = time();
// cachebust icons
if($calcIconsVer>0){ foreach($calcIcons as $k=>$v){ if(!$v) continue; $sep = (strpos($v,'?')===false)?'?':'&'; $calcIcons[$k] = $v . $sep . 'v=' . $calcIconsVer; } }

?><!doctype html>
<html lang="<?= $lang ?>">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>Calculator preview</title>
  <link rel="stylesheet" href="/site.css?v=<?= (int)$prevVer ?>" />
  <link rel="stylesheet" href="/site.mobile.css?v=<?= (int)$prevVer ?>" />
  <script>window.CALC_UI = <?= json_encode($calcUi, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;</script>
  <script>window.CALC_ICONS = <?= json_encode($calcIcons, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;</script>
  <style>
    body{margin:0;padding:24px;background:#0b1026}
    .wrap{max-width:760px;margin:0 auto}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card calc2">
      <h2 style="margin:0 0 12px"><?= $lang==='en'?'Exchange calculator':'Калькулятор обміну' ?></h2>

      <form id="ppForm">
        <div class="calc2Rows">

          <div class="calc2Row">
            <div class="calc2Meta">
              <div class="calc2Label"><?= h($calcUi['label_currency'] ?? ($lang==='en'?'Currency':'Валюта')) ?></div>
              <div class="calc2Label"><?= h($calcUi['label_amount'] ?? ($lang==='en'?'Amount':'Кількість')) ?></div>
            </div>

            <div class="fieldRow">
              <div class="assetSelectWrap">
                <span class="calc2Flag" id="fromFlag">🇺🇦</span>
                <select class="assetSelect" id="fromAssetSelect" aria-label="From currency"></select>
              </div>

              <input id="fromAmount" inputmode="decimal" placeholder="0" value="0">
            </div>
          </div>

          <div class="swapWrap">
            <button id="swapBtn" class="swapBtn" type="button" aria-label="<?= h($calcUi['aria_swap'] ?? ($lang==='en'?'Swap':'Поміняти місцями')) ?>">
              <span class="swapIcon">⇅</span>
            </button>
          </div>

          <div class="calc2Row">
            <div class="calc2Meta">
              <div class="calc2Label"><?= h($calcUi['label_currency'] ?? ($lang==='en'?'Currency':'Валюта')) ?></div>
              <div class="calc2Label"><?= h($calcUi['label_amount'] ?? ($lang==='en'?'Amount':'Кількість')) ?></div>
            </div>

            <div class="fieldRow">
              <div class="assetSelectWrap">
                <span class="calc2Flag" id="toFlag">💱</span>
                <select class="assetSelect" id="toAssetSelect" aria-label="To currency"></select>
              </div>

              <input id="toAmount" inputmode="decimal" placeholder="0" value="0" readonly>
            </div>
          </div>

          <div class="calc2Contact">
            <input id="contact" placeholder="<?= h($calcUi['placeholder_phone'] ?? ($lang==='en'?'Phone':'Телефон')) ?>">
          </div>

          <div class="calc2Foot">
            <div>
              <div class="calc2Rate" id="rateText">1 USDT = — UAH</div>
              <div class="calc2FeeWrap" id="feeWrap" style="display:none">
                <div class="calc2Fee" id="feeText"></div>
              </div>
            </div>

            <button class="calc2Submit" id="submitBtn" type="submit"><?= h($calcUi['btn_submit'] ?? ($lang==='en'?'EXCHANGE':'ПОМІНЯТИ ВАЛЮТУ')) ?></button>
          </div>

          <div class="calc2Receipt" id="receipt"></div>
        </div>
</div>

      </form>
    </div>
  </div>

  <script src="/site.js?v=<?= (int)$prevVer ?>"></script>
</body>
</html>
