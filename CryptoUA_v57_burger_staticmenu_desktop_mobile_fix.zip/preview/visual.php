<?php
require_once __DIR__ . '/../helpers.php';
require_login();
$lang = ($_GET['lang'] ?? 'uk') === 'en' ? 'en' : 'uk';

$ver = (int)setting_get('visual_ver', 0);

$theme = setting_get('theme', []);
if(!is_array($theme)) $theme = [];
$themeDefaults = [
  'bg1' => 'rgba(124,92,255,.18)',
  'bg2' => 'rgba(35,213,171,.14)',
  'bg3' => 'rgba(124,92,255,.10)',
  'btn1'=> 'rgba(124,92,255,.95)',
  'btn2'=> 'rgba(35,213,171,.95)',
  'cta1'=> '#22d3a9',
  'cta2'=> '#2cff8a',
  'ctaGlow'=> 'rgba(34,211,169,.55)',
];
$theme = array_merge($themeDefaults, $theme);

$theme_mode = (string)setting_get('theme_mode', 'night');
if($theme_mode !== 'day') $theme_mode = 'night';

$burger_icon = (string)setting_get('burger_icon', '');
$burger_ver = (int)setting_get('burger_icon_ver', 0);
if($burger_ver<=0) $burger_ver = (int)setting_get('brand_assets_ver', 0);


if($ver<=0) $ver = time();

$logo = (string)setting_get('brand_logo', '/assets/logo.svg');
$reviews = setting_get('reviews_media', ['r1'=>'','r2'=>'','r3'=>'']);
if(!is_array($reviews)) $reviews = ['r1'=>'','r2'=>'','r3'=>''];

function with_ver(string $url, int $ver): string {
  if($ver<=0 || !$url) return $url;
  $sep = (strpos($url,'?')===false) ? '?' : '&';
  return $url . $sep . 'v=' . $ver;
}
?><!doctype html>
<html lang="<?= $lang ?>" class="<?php echo ($theme_mode==='day')?'theme-day':'theme-night'; ?>">
<head>
  <meta charset="utf-8" />
<script>
(function(){
  try{
    var m = localStorage.getItem('themeMode');
    if(m==='day'){ document.documentElement.classList.add('theme-day'); document.documentElement.classList.remove('theme-night'); }
    if(m==='night'){ document.documentElement.classList.add('theme-night'); document.documentElement.classList.remove('theme-day'); }
  }catch(e){}
})();
</script>

  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <link rel="stylesheet" href="/site.css?v=<?= (int)$ver ?>" />
  <link rel="stylesheet" href="/site.mobile.css?v=<?= (int)$ver ?>" />
  <style>body{margin:0;background:#0b1026}</style>

  <style id="themeVars">
    :root{
      --theme-bg1: <?= h($theme['bg1']) ?>;
      --theme-bg2: <?= h($theme['bg2']) ?>;
      --theme-bg3: <?= h($theme['bg3']) ?>;
      --theme-btn1: <?= h($theme['btn1']) ?>;
      --theme-btn2: <?= h($theme['btn2']) ?>;
      --theme-cta1: <?= h($theme['cta1']) ?>;
      --theme-cta2: <?= h($theme['cta2']) ?>;
      --theme-ctaGlow: <?= h($theme['ctaGlow']) ?>;
    }
  </style>
</head>
<body>
<header class="header">
  <div class="container header__inner">
    <a class="logo" href="#">
      <img class="logo__img" src="<?= h(with_ver($logo,$ver)) ?>" alt="CryptoUA" style="height:30px" />
    </a>
    <div class="lang">
      <a class="lang__btn active" href="#">UA</a>
      <a class="lang__btn" href="#">EN</a>
    </div>
    <button class="themeToggleBtn" id="themeToggleBtn" type="button" aria-label="Day/Night" aria-pressed="false" title="Day/Night">
          <span class="ttIcon">☀</span>
          <span class="ttTrack"><span class="ttThumb"></span></span>
          <span class="ttIcon">☾</span>
        </button>
    <button class="burgerBtn" data-has-icon="<?= $burger_icon?'1':'0' ?>" style="<?php if($burger_icon){ $u=$burger_icon; $sep=(strpos($u,'?')===false)?'?':'&'; echo 'background-image:url('.h($u.$sep.'v='.$burger_ver).');'; } ?>" type="button" aria-label="Menu" aria-expanded="false"><span></span><span></span><span></span></button>
  </div>
</header>

<main class="container" style="padding:18px 16px 30px">
  <section class="section" id="reviews">
    <h2 style="margin:0 0 12px"><?= $lang==='en'?'Reviews':'Відгуки' ?></h2>
    <div class="grid3">
      <?php foreach(['r1','r2','r3'] as $k): ?>
        <div class="reviewCard">
          <div class="reviewTop">
            <?php if(!empty($reviews[$k])): ?>
              <img src="<?= h(with_ver($reviews[$k],$ver)) ?>" alt="<?= h($k) ?>" class="reviewAvatar" />
            <?php else: ?>
              <div class="reviewAvatar ph"></div>
            <?php endif; ?>
            <div>
              <div class="reviewName">User</div>
              <div class="reviewMeta">Telegram</div>
            </div>
          </div>
          <div class="reviewText">Preview review text…</div>
        </div>
      <?php endforeach; ?>
    </div>
  </section>
</main>

<script>
  // live preview from admin/visual.php (no save)
  window.addEventListener('message', function(ev){
    try{
      const data = ev && ev.data ? ev.data : null;
      if(!data || data.type !== 'theme_preview') return;
      const v = data.vars || {};
      // theme mode class
      try{
        const mode = (v.theme_mode==='day') ? 'day' : 'night';
        document.documentElement.classList.toggle('theme-day', mode==='day');
        document.documentElement.classList.toggle('theme-night', mode!=='day');
      }catch(e){}
      const r = document.documentElement.style;
      if(v.bg1) r.setProperty('--theme-bg1', v.bg1);
      if(v.bg2) r.setProperty('--theme-bg2', v.bg2);
      if(v.bg3) r.setProperty('--theme-bg3', v.bg3);
      if(v.btn1) r.setProperty('--theme-btn1', v.btn1);
      if(v.btn2) r.setProperty('--theme-btn2', v.btn2);
      if(v.cta1) r.setProperty('--theme-cta1', v.cta1);
      if(v.cta2) r.setProperty('--theme-cta2', v.cta2);
      if(v.ctaGlow) r.setProperty('--theme-ctaGlow', v.ctaGlow);
    }catch(e){}
  });
</script>
</body>
</html>
