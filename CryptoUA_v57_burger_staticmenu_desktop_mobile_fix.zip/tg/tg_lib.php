<?php
require_once __DIR__ . '/../helpers.php';

function tg_request(string $method, array $payload): array {
  $token = cfg('TELEGRAM_BOT_TOKEN', '');
  if (!$token) return ['ok'=>false, 'error'=>'no_token'];
  $url = "https://api.telegram.org/bot{$token}/{$method}";
  $opts = [
    'http' => [
      'method'  => 'POST',
      'header'  => "Content-Type: application/json\r\n",
      'content' => json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),
      'timeout' => 12
    ]
  ];
  $ctx = stream_context_create($opts);
  $res = @file_get_contents($url, false, $ctx);
  if ($res === false) return ['ok'=>false, 'error'=>'http'];
  $data = json_decode($res, true);
  return $data ?: ['ok'=>false, 'error'=>'bad_json'];
}

function tg_keyboard_for_order(int $orderId, string $status): array {
  $mk = fn($label,$st)=>['text'=>$label,'callback_data'=>"STATUS|{$orderId}|{$st}"];
  return [
    'inline_keyboard' => [
      [ $mk('🧑‍💻 Взяти в роботу','IN_WORK'), $mk('⏳ Очікує оплату','WAIT_PAYMENT') ],
      [ $mk('✅ Підтвердити оплату','PAID'), $mk('💸 Виплачено / Завершено','COMPLETED') ],
      [ $mk('❌ Відхилити','REJECTED') ]
    ]
  ];
}

function tg_order_text(array $o): string {
  $lines = [];
  $lines[] = "🧾 *Заявка #{$o['id']}*";
  $lines[] = "Статус: *{$o['status']}*";
  $lines[] = "";
  $lines[] = "Напрям: `{$o['mode']}`";
  $lines[] = "FROM: `{$o['from_amount']} {$o['from_asset']}`";
  $lines[] = "TO: `{$o['to_amount']} {$o['to_asset']}`";
  if ($o['payout'] !== '') $lines[] = "Реквізити: `{$o['payout']}`";
  $lines[] = "";
  if ($o['name'] !== '') $lines[] = "Ім'я: *" . str_replace(['*','_','`'],['','',''],$o['name']) . "*";
  if ($o['contact'] !== '') $lines[] = "Контакт: `" . $o['contact'] . "`";
  $lines[] = "Quote: #{$o['quote_id']} (fee {$o['fee_pct']}%)";
  $lines[] = "Час: {$o['created_at']}";
  return implode("\n",$lines);
}
