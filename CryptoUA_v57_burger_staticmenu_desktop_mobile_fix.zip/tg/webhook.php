<?php
require_once __DIR__ . '/../helpers.php';
require __DIR__ . '/tg_lib.php';

if (!is_installed()) { http_response_code(400); echo "not_installed"; exit; }

$secret = cfg('TG_WEBHOOK_SECRET','');
if ($secret) {
  $tok = $_GET['token'] ?? '';
  if (!hash_equals($secret, $tok)) { http_response_code(403); echo "forbidden"; exit; }
}

$update = json_decode(file_get_contents('php://input'), true) ?: [];
$pdo = db();

if (isset($update['callback_query'])) {
  $cq = $update['callback_query'];
  $data = (string)($cq['data'] ?? '');
  $cbid = $cq['id'] ?? '';
  $msg = $cq['message'] ?? null;

  $parts = explode('|', $data);
  if (count($parts) === 3 && $parts[0] === 'STATUS') {
    $orderId = (int)$parts[1];
    $newStatus = strtoupper(trim($parts[2]));
    $allowed = ['NEW','IN_WORK','WAIT_PAYMENT','PAID','COMPLETED','REJECTED','CANCELLED'];
    if (!in_array($newStatus, $allowed, true)) $newStatus = 'IN_WORK';

    $o = $pdo->prepare("SELECT * FROM orders WHERE id=?");
    $o->execute([$orderId]);
    $order = $o->fetch();
    if ($order) {
      $old = $order['status'];
      $pdo->prepare("UPDATE orders SET status=?, updated_at=? WHERE id=?")->execute([$newStatus, now_iso(), $orderId]);

      session_start();
      $_SESSION['user'] = ['username'=>'telegram','role'=>'system'];
      audit('ORDER_STATUS', ['orderId'=>$orderId,'from'=>$old,'to'=>$newStatus,'by'=>'telegram']);

      if ($msg && isset($msg['chat']['id']) && isset($msg['message_id'])) {
        $chatId = $msg['chat']['id'];
        $messageId = $msg['message_id'];
        $order2 = $pdo->query("SELECT * FROM orders WHERE id=".(int)$orderId)->fetch();
        tg_request('editMessageText', [
          'chat_id'=>$chatId,
          'message_id'=>$messageId,
          'text'=>tg_order_text($order2),
          'parse_mode'=>'Markdown',
          'reply_markup'=>tg_keyboard_for_order($orderId, $newStatus)
        ]);
      }
      tg_request('answerCallbackQuery', ['callback_query_id'=>$cbid, 'text'=>"Статус: {$newStatus}"]);
      echo "OK";
      exit;
    }
  }
  tg_request('answerCallbackQuery', ['callback_query_id'=>$cbid, 'text'=>"Помилка"]);
  echo "OK";
  exit;
}

echo "OK";
